# Results — task `family` (test set, n=908)

| id | model | family | val_acc | accuracy | precision | recall | f1 | roc_auc | train_s | infer_s | qubits | params |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | classical ML | 0.988 | 0.982 | 0.977 | 0.984 | 0.980 | 0.989 | 38.4 | 2.9 | - | k=1 |
| 2 | K-mer + SVM | classical ML | 0.943 | 0.939 | 0.945 | 0.926 | 0.935 | 0.992 | 21.8 | 0.01 | - | C=10.0 |
| 3 | Features + XGBoost | classical ML | 0.882 | 0.885 | 0.916 | 0.852 | 0.878 | 0.986 | 78.0 | 0.01 | - | trees=149 |
| 4 | Encoding + 1D-CNN | deep learning | 0.865 | 0.871 | 0.876 | 0.854 | 0.864 | 0.980 | 48.8 | 0.18 | - | L=1024 |
| 5 | Encoding + CNN-LSTM | deep learning | 0.692 | 0.686 | 0.687 | 0.654 | 0.659 | 0.914 | 31.8 | 0.14 | - | L=1024 |
| 6 | PCA + QSVM | quantum | 0.687 | 0.652 | 0.636 | 0.618 | 0.626 | 0.860 | 2.1 | 0.05 | 8 | ZZ-map bw=0.4 C=100.0 n_train=2000 |
| 7 | PCA + QNN | quantum | 0.484 | 0.474 | 0.413 | 0.438 | 0.415 | 0.801 | 108.8 | 0.08 | 8 | 3 re-upload blocks |
| 8 | CNN + QNN | hybrid | 0.789 | 0.772 | 0.787 | 0.768 | 0.772 | 0.937 | 881.6 | 6.7 | 8 | end-to-end |
| 9 | BiLSTM + QNN | hybrid | 0.549 | 0.570 | 0.565 | 0.605 | 0.577 | 0.848 | 170.5 | 0.36 | 8 | end-to-end |
| 10 | QAOA + QNN | quantum | 0.450 | 0.456 | 0.381 | 0.380 | 0.373 | 0.763 | 14.4 | 0.02 | 12 | QAOA p=2 -> ['TGT', 'AGA', 'GGT', 'CTT', 'CAG', 'TGC'] (approx ratio 1.00, P(opt)=0.001 vs uniform 0.0002) |
| 11 | VQE + QNN | quantum | 0.486 | 0.469 | 0.388 | 0.409 | 0.391 | 0.782 | 101.2 | 0.11 | 8 | VQE E=-6.624 vs exact -7.825 |
| 12 | QML + CNN | hybrid | 0.826 | 0.831 | 0.845 | 0.825 | 0.832 | 0.972 | 14.8 | 0.13 | 4 | quanv window=8 stride=4 -> 8x255 |
