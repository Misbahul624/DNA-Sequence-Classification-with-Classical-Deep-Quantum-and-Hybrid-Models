# Results — task `species` (test set, n=899)

| id | model | family | val_acc | accuracy | precision | recall | f1 | roc_auc | train_s | infer_s | qubits | params |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | classical ML | 0.607 | 0.552 | 0.513 | 0.459 | 0.474 | 0.587 | 38.2 | 2.7 | - | k=1 |
| 2 | K-mer + SVM | classical ML | 0.612 | 0.598 | 0.586 | 0.505 | 0.531 | 0.694 | 25.8 | 0.01 | - | C=10.0 |
| 3 | Features + XGBoost | classical ML | 0.569 | 0.586 | 0.608 | 0.427 | 0.446 | 0.729 | 15.1 | 0.00 | - | trees=28 |
| 4 | Encoding + 1D-CNN | deep learning | 0.540 | 0.553 | 0.450 | 0.458 | 0.417 | 0.678 | 14.8 | 0.15 | - | L=1024 |
| 5 | Encoding + CNN-LSTM | deep learning | 0.533 | 0.562 | 0.564 | 0.467 | 0.407 | 0.666 | 11.8 | 0.12 | - | L=1024 |
| 6 | PCA + QSVM | quantum | 0.595 | 0.594 | 0.198 | 0.333 | 0.248 | 0.526 | 2.5 | 0.04 | 8 | ZZ-map bw=0.1 C=1.0 n_train=2000 |
| 7 | PCA + QNN | quantum | 0.463 | 0.445 | 0.397 | 0.398 | 0.380 | 0.615 | 48.4 | 0.08 | 8 | 3 re-upload blocks |
| 8 | CNN + QNN | hybrid | 0.537 | 0.562 | 0.397 | 0.464 | 0.397 | 0.680 | 311.3 | 6.4 | 8 | end-to-end |
| 9 | BiLSTM + QNN | hybrid | 0.541 | 0.567 | 0.394 | 0.463 | 0.400 | 0.646 | 59.2 | 0.36 | 8 | end-to-end |
| 10 | QAOA + QNN | quantum | 0.454 | 0.476 | 0.419 | 0.422 | 0.405 | 0.618 | 14.8 | 0.02 | 12 | QAOA p=2 -> ['ATG', 'CTC', 'GAC', 'GGT', 'GCA', 'ACT'] (approx ratio 1.00, P(opt)=0.001 vs uniform 0.0002) |
| 11 | VQE + QNN | quantum | 0.463 | 0.475 | 0.433 | 0.433 | 0.392 | 0.627 | 73.3 | 0.11 | 8 | VQE E=-6.118 vs exact -8.233 |
| 12 | QML + CNN | hybrid | 0.560 | 0.539 | 0.467 | 0.430 | 0.404 | 0.696 | 10.5 | 0.14 | 4 | quanv window=8 stride=4 -> 8x255 |
