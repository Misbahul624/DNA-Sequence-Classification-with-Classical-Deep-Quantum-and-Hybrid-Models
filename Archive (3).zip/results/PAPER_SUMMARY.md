# Paper summary: DNA sequence classification with classical, deep, quantum and hybrid models

Generated from the full run (`python3 run.py`, default "fast" settings, seed 42). All numbers are test-set results on held-out data, scored once after model selection on the validation set.

## 1. Data

* Source: Kaggle "DNA Sequence Dataset" (nageshsingh/dna-sequence-dataset). Files: human.txt, chimpanzee.txt, dog.txt. Each line is a sequence and its gene-family label (7 classes).
* Cleaning: uppercase; any non-ACGT symbol mapped to N; sequences shorter than 30 bases or with more than 5% N removed; exact duplicate sequences removed; sequences with conflicting labels removed (no leakage across splits).
* Split: stratified 70 / 15 / 15 train / validation / test, random seed 42, saved in `data/splits/`.

| Task | Unique sequences | Train | Validation | Test | Classes |
|---|---|---|---|---|---|
| Gene family (`family`) | 6,050 | 4,235 | 907 | 908 | 7 (GPCR, Tyr kinase, Tyr phosphatase, Synthetase, Synthase, Ion channel, Transcription factor) |
| Species (`species`) | 5,990 | 4,193 | 898 | 899 | 3 (human, chimpanzee, dog) |

Class balance: in the family test set the largest class (Transcription factor) is 30.6% of sequences. In the species test set the largest class (human) is 59.4% of sequences, which is important when reading the species results (see section 5).

## 2. Features

* k-mer TF-IDF, k = 3..6 (5,683 dimensions after min_df = 2), for KNN and SVM.
* TF-IDF k = 3..5 plus composition features (A/C/G/T frequency, GC content, GC and AT skew, CpG observed/expected, log length, N fraction) for XGBoost.
* One-hot encoding, 4 x 1024, sequences trimmed or zero-padded to 1,024 bases, for the CNN, LSTM and hybrid models. 56% of training sequences are longer than 1,024 bases, so their tails are cut off.
* 3-mer and 4-mer frequencies standardised, then reduced by PCA to 8 components (39.5% of variance retained), then scaled to [0, π] as rotation angles for the quantum models.

## 3. Models

All 12 models use the same splits and seed. Hyper-parameters are chosen on the validation set only.

| # | Model | Family | Key settings |
|---|---|---|---|
| 1 | K-mer + KNN | Classical ML | cosine distance, distance-weighted, k chosen from {1, 3, 5, 9} |
| 2 | K-mer + SVM | Classical ML | linear SVM, C chosen from {0.1, 1, 10} |
| 3 | Features + XGBoost | Classical ML | up to 150 trees, depth 6, learning rate 0.15, early stopping (30 rounds), trained in a separate process |
| 4 | Encoding + 1D-CNN | Deep learning | 3 conv layers (64/128/128 channels), global max pool, AdamW, cosine LR, up to 15 epochs, patience 5 |
| 5 | Encoding + CNN-LSTM | Deep learning | 2 conv layers, LSTM (64 units), same training |
| 6 | PCA + QSVM | Quantum | 8-qubit ZZ feature map (2 reps), fidelity kernel, SVC; bandwidth and C chosen on validation; training subsampled to 2,000 sequences |
| 7 | PCA + QNN | Quantum | 8-qubit variational circuit, 3 data re-uploading blocks, linear read-out; up to 20 epochs |
| 8 | CNN + QNN | Hybrid | CNN features to 8 angles, 8-qubit QNN (2 blocks), end-to-end training |
| 9 | BiLSTM + QNN | Hybrid | strided conv + BiLSTM to 8 angles, 8-qubit QNN, end-to-end training |
| 10 | QAOA + QNN | Quantum | QAOA (p = 2) on 12 candidate 3-mers, solves a QUBO to select 6 features (relevance from mutual information, redundancy from correlation); 6-qubit QNN on the selected features |
| 11 | VQE + QNN | Quantum | VQE (3 layers, 150 steps) on an Ising Hamiltonian built from training features; the QNN starts from the VQE ground state |
| 12 | QML + CNN | Hybrid | quanvolution: 4-qubit fixed random circuit on each 8-base window (stride 4) produces 8 channels, then a 1D-CNN |

Quantum circuits are simulated exactly on a classical computer (state-vector simulator written in PyTorch). No quantum hardware was used.

Training: AdamW, cosine learning-rate schedule, class-weighted cross-entropy, best-validation-accuracy checkpoint restored before testing. Early stopping on validation accuracy. Quantum models: learning rate 0.02, up to 20 epochs, patience 6.

## 4. Results

### 4a. Gene-family task (7 classes, n = 908 test sequences)

| # | Model | Val acc | Test acc | Precision | Recall | Macro F1 | Macro ROC-AUC | Train time (s) | Test inference (s) | Qubits |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | 0.988 | **0.982** | 0.977 | 0.984 | **0.980** | 0.989 | 38.4 | 2.87 | - |
| 2 | K-mer + SVM | 0.943 | 0.939 | 0.945 | 0.926 | 0.935 | 0.992 | 21.8 | 0.01 | - |
| 3 | Features + XGBoost | 0.882 | 0.885 | 0.916 | 0.852 | 0.878 | 0.986 | 78.0 | 0.01 | - |
| 4 | Encoding + 1D-CNN | 0.865 | 0.871 | 0.876 | 0.854 | 0.864 | 0.980 | 48.8 | 0.18 | - |
| 5 | Encoding + CNN-LSTM | 0.692 | 0.686 | 0.687 | 0.654 | 0.659 | 0.914 | 31.8 | 0.14 | - |
| 6 | PCA + QSVM | 0.687 | 0.652 | 0.636 | 0.618 | 0.626 | 0.860 | 2.1 | 0.05 | 8 |
| 7 | PCA + QNN | 0.484 | 0.474 | 0.413 | 0.438 | 0.415 | 0.801 | 108.8 | 0.08 | 8 |
| 8 | CNN + QNN | 0.789 | 0.772 | 0.787 | 0.768 | 0.772 | 0.937 | 881.6 | 6.71 | 8 |
| 9 | BiLSTM + QNN | 0.549 | 0.570 | 0.565 | 0.605 | 0.577 | 0.848 | 170.5 | 0.36 | 8 |
| 10 | QAOA + QNN | 0.450 | 0.456 | 0.381 | 0.380 | 0.373 | 0.763 | 14.4 | 0.02 | 12 (QAOA) / 6 (QNN) |
| 11 | VQE + QNN | 0.486 | 0.469 | 0.388 | 0.409 | 0.391 | 0.782 | 101.2 | 0.11 | 8 |
| 12 | QML + CNN | 0.826 | **0.831** | 0.845 | 0.825 | **0.832** | 0.972 | 14.8 | 0.13 | 4 |

Best overall: K-mer + KNN (test accuracy 0.982). Best quantum or hybrid model: QML + CNN (0.831).

### 4b. Species task (3 classes, n = 899 test sequences; majority class 59.4%)

| # | Model | Val acc | Test acc | Precision | Recall | Macro F1 | Macro ROC-AUC | Train time (s) | Qubits |
|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | 0.607 | 0.552 | 0.513 | 0.459 | 0.474 | 0.587 | 38.2 | - |
| 2 | K-mer + SVM | 0.612 | **0.598** | 0.586 | 0.505 | 0.531 | 0.694 | 25.8 | - |
| 3 | Features + XGBoost | 0.569 | 0.586 | 0.608 | 0.427 | 0.446 | 0.729 | 15.1 | - |
| 4 | Encoding + 1D-CNN | 0.540 | 0.553 | 0.450 | 0.458 | 0.417 | 0.678 | 14.8 | - |
| 5 | Encoding + CNN-LSTM | 0.533 | 0.562 | 0.564 | 0.467 | 0.407 | 0.666 | 11.8 | - |
| 6 | PCA + QSVM | 0.595 | 0.594 | 0.198 | 0.333 | 0.248 | 0.526 | 2.5 | 8 |
| 7 | PCA + QNN | 0.463 | 0.445 | 0.397 | 0.398 | 0.380 | 0.615 | 48.4 | 8 |
| 8 | CNN + QNN | 0.537 | 0.562 | 0.397 | 0.464 | 0.397 | 0.680 | 311.3 | 8 |
| 9 | BiLSTM + QNN | 0.541 | 0.567 | 0.394 | 0.463 | 0.400 | 0.646 | 59.2 | 8 |
| 10 | QAOA + QNN | 0.454 | 0.476 | 0.419 | 0.422 | 0.405 | 0.618 | 14.8 | 12 / 6 |
| 11 | VQE + QNN | 0.463 | 0.475 | 0.433 | 0.433 | 0.392 | 0.627 | 73.3 | 8 |
| 12 | QML + CNN | 0.560 | 0.539 | 0.467 | 0.430 | 0.404 | 0.696 | 10.5 | 4 |

## 5. Interpretation and limitations (please read before writing the discussion)

1. **Classical k-mer models dominate the gene-family task.** K-mer + KNN reaches 0.982 test accuracy. Human and chimpanzee homologous genes are very similar, so a nearest-neighbour match usually identifies the family correctly.

2. **The quantum and hybrid models underperform the classical baselines on both tasks.** The best quantum-only model, PCA + QSVM, reaches 0.652 on the family task. The best quantum or hybrid model overall, QML + CNN (0.831), is still below the classical models. The quantum components here are simulated on an 8-qubit (or fewer) classical computer with only a few hundred training steps, so this result should not be read as a general judgement of quantum machine learning.

3. **The species task is close to the majority-class baseline for most models.** The human class is 59.4% of the test set. PCA + QSVM scores 0.594 test accuracy, which equals the majority-class share exactly, and its macro F1 of 0.248 shows it predicts essentially one class. Most other species models score 0.55 to 0.60. Only K-mer + SVM (0.598) and XGBoost (0.586) score noticeably higher, and even their macro F1 is about 0.45 to 0.53. Accuracy alone is misleading on this task. Report macro F1 and per-class results, and consider reporting a majority-class baseline in the paper.

4. **Several deep and quantum models stopped early at epoch 1 or 3 on the species task** (1D-CNN, CNN-LSTM, CNN + QNN, BiLSTM + QNN) because validation accuracy never improved. Their results are close to chance and reflect a weak training signal on this 3-class problem rather than a fully tuned model.

5. **QAOA results need careful wording.** The QAOA step did find the exact optimum of the feature-selection QUBO (approximation ratio 1.00 on both tasks), but the optimum had probability 0.001 in the final state, against a uniform 0.0002. Describe it as "QAOA recovered the exact optimum of the selection problem" and do not claim it solved classification.

6. **Run settings.** Results come from the default fast settings: 15 deep-learning epochs, 20 quantum epochs, QSVM training capped at 2,000 sequences, 150 VQE steps. The `--full` setting (40 / 50 epochs, uncapped QSVM, 300 VQE steps) may change the numbers, and it has not been run.

7. **Single seed.** All results use seed 42 only. No confidence intervals or repeated runs exist, so differences of about 1 to 2 percentage points should not be interpreted as significant.

8. **Sequence length.** The one-hot models see the first 1,024 bases only, which affects the 56% of training sequences that are longer.

## 6. Environment

* Hardware: MacBook Air, Apple Silicon (arm64). The classical deep-learning models (1D-CNN, CNN-LSTM, QML + CNN) used the Apple GPU (MPS) when available. Quantum and hybrid-quantum models ran on CPU, because the quantum simulator uses complex arithmetic.
* Python 3.14.7; PyTorch 2.12.1; scikit-learn 1.9.0; XGBoost 3.3.0; NumPy 2.5.0.
* Run time, from the training log: the family task took about 26 minutes (00:00 to 00:26) and the species task about 11 minutes (00:26 to 00:37), about 37 minutes in total.

## 7. Reproduction

```bash
cd quantum
pip install -r requirements.txt
python3 run.py                 # both tasks, all 12 models, writes results/REPORT.md
```

Cached results are kept in `results/cache/`. Re-running with `--resume` reuses finished models when the settings and data are unchanged.

## 8. Files

* `results/REPORT.md`: full report with all figures.
* `results/metrics_family.csv`, `results/metrics_species.csv`: per-model metrics.
* `results/summary_family.md`, `results/summary_species.md`: tables.
* `results/plots/`: accuracy, validation vs test, training time, confusion matrices (grid and per model), per-class F1, ROC curves.
* `results/train_log.txt`: full timestamped training log.
