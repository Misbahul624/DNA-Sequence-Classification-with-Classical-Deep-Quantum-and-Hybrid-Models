# DNA Sequence Classification — ML · DL · QML · Hybrid Report
_Generated 2026-11-23 16:04_

Pipeline: DNA dataset (Kaggle *DNA Sequence Dataset*: human, chimpanzee, dog) → cleaning & de-duplication → k-mer / one-hot / composition features → PCA → 12 models → validation-based model selection → single evaluation on the held-out test set.

| # | Model | Family |
|---|---|---|
| 1 | K-mer + KNN | classical ML |
| 2 | K-mer + SVM | classical ML |
| 3 | Features + XGBoost | classical ML |
| 4 | Encoding + 1D-CNN | deep learning |
| 5 | Encoding + CNN-LSTM | deep learning |
| 6 | PCA + QSVM | quantum |
| 7 | PCA + QNN | quantum |
| 8 | CNN + QNN | hybrid |
| 9 | BiLSTM + QNN | hybrid |
| 10 | QAOA + QNN | quantum |
| 11 | VQE + QNN | quantum |
| 12 | QML + CNN | hybrid |

Quantum circuits are run on an exact state-vector simulator (classical simulation, not hardware). Metrics: accuracy, macro precision / recall / F1, macro one-vs-rest ROC-AUC, training and inference time.

**Run configuration:** mode=fast, seed=42, sequence length=1024, PCA=8, qubits=8, DL epochs≤15, QNN epochs≤20, QSVM train cap=2000, runtime this session 37.3 min


## Task: `family` — 7-class gene-family classification (human + chimpanzee + dog pooled)

**6050** unique sequences, **7** classes → train **4235** / validation **907** / test **908** (stratified 70/15/15, seed 42).

* Best overall: **1. K-mer + KNN**, test accuracy **0.982**, macro F1 **0.980**
* Best quantum / hybrid: **12. QML + CNN**, test accuracy **0.831**, macro F1 **0.832**

### Class distribution

| class | train | val | test |
|---|---|---|---|
| GPCR | 563 | 120 | 121 |
| Tyr kinase | 466 | 100 | 99 |
| Tyr phosphatase | 346 | 74 | 74 |
| Synthetase | 619 | 132 | 133 |
| Synthase | 680 | 146 | 146 |
| Ion channel | 265 | 57 | 57 |
| Transcr. factor | 1296 | 278 | 278 |


![class distribution](plots/classes_family.png)

### Results (test set)

| id | model | family | val_acc | accuracy | precision | recall | f1 | roc_auc | train_s | infer_s | qubits |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | classical ML | 0.988 | 0.982 | 0.977 | 0.984 | 0.980 | 0.989 | 38.4 | 2.9 | - |
| 2 | K-mer + SVM | classical ML | 0.943 | 0.939 | 0.945 | 0.926 | 0.935 | 0.992 | 21.8 | 0.01 | - |
| 3 | Features + XGBoost | classical ML | 0.882 | 0.885 | 0.916 | 0.852 | 0.878 | 0.986 | 78.0 | 0.01 | - |
| 4 | Encoding + 1D-CNN | deep learning | 0.865 | 0.871 | 0.876 | 0.854 | 0.864 | 0.980 | 48.8 | 0.18 | - |
| 5 | Encoding + CNN-LSTM | deep learning | 0.692 | 0.686 | 0.687 | 0.654 | 0.659 | 0.914 | 31.8 | 0.14 | - |
| 6 | PCA + QSVM | quantum | 0.687 | 0.652 | 0.636 | 0.618 | 0.626 | 0.860 | 2.1 | 0.05 | 8 |
| 7 | PCA + QNN | quantum | 0.484 | 0.474 | 0.413 | 0.438 | 0.415 | 0.801 | 108.8 | 0.08 | 8 |
| 8 | CNN + QNN | hybrid | 0.789 | 0.772 | 0.787 | 0.768 | 0.772 | 0.937 | 881.6 | 6.7 | 8 |
| 9 | BiLSTM + QNN | hybrid | 0.549 | 0.570 | 0.565 | 0.605 | 0.577 | 0.848 | 170.5 | 0.36 | 8 |
| 10 | QAOA + QNN | quantum | 0.450 | 0.456 | 0.381 | 0.380 | 0.373 | 0.763 | 14.4 | 0.02 | 12 |
| 11 | VQE + QNN | quantum | 0.486 | 0.469 | 0.388 | 0.409 | 0.391 | 0.782 | 101.2 | 0.11 | 8 |
| 12 | QML + CNN | hybrid | 0.826 | 0.831 | 0.845 | 0.825 | 0.832 | 0.972 | 14.8 | 0.13 | 4 |


### Model comparison

![accuracy](plots/accuracy_family.png)

![validation vs test](plots/val_vs_test_family.png)  ![training time](plots/time_family.png)

### Confusion matrices (row-normalised)

![confusion matrices](plots/confusion_family.png)

### Per-class F1

![per-class F1](plots/per_class_f1_family.png)

### ROC curves

![ROC](plots/roc_family.png)

### Model details

<details><summary><b>1. K-mer + KNN</b> (classical ML) — acc 0.982, F1 0.980, AUC 0.989</summary>

* Settings: k=1
* Validation accuracy 0.988; precision 0.977; recall 0.984; train 38.4s; test inference 2.87s

![confusion 1](plots/confusion/family_01.png)

</details>

<details><summary><b>2. K-mer + SVM</b> (classical ML) — acc 0.939, F1 0.935, AUC 0.992</summary>

* Settings: C=10.0
* Validation accuracy 0.943; precision 0.945; recall 0.926; train 21.8s; test inference 0.01s

![confusion 2](plots/confusion/family_02.png)

</details>

<details><summary><b>3. Features + XGBoost</b> (classical ML) — acc 0.885, F1 0.878, AUC 0.986</summary>

* Settings: trees=149
* Validation accuracy 0.882; precision 0.916; recall 0.852; train 78.0s; test inference 0.01s

![confusion 3](plots/confusion/family_03.png)

</details>

<details><summary><b>4. Encoding + 1D-CNN</b> (deep learning) — acc 0.871, F1 0.864, AUC 0.980</summary>

* Settings: L=1024
* Validation accuracy 0.865; precision 0.876; recall 0.854; train 48.8s; test inference 0.18s

![confusion 4](plots/confusion/family_04.png)

</details>

<details><summary><b>5. Encoding + CNN-LSTM</b> (deep learning) — acc 0.686, F1 0.659, AUC 0.914</summary>

* Settings: L=1024
* Validation accuracy 0.692; precision 0.687; recall 0.654; train 31.8s; test inference 0.14s

![confusion 5](plots/confusion/family_05.png)

</details>

<details><summary><b>6. PCA + QSVM</b> (quantum) — acc 0.652, F1 0.626, AUC 0.860</summary>

* Settings: ZZ-map bw=0.4 C=100.0 n_train=2000
* Validation accuracy 0.687; precision 0.636; recall 0.618; train 2.1s; test inference 0.05s; 8 qubits

![confusion 6](plots/confusion/family_06.png)

</details>

<details><summary><b>7. PCA + QNN</b> (quantum) — acc 0.474, F1 0.415, AUC 0.801</summary>

* Settings: 3 re-upload blocks
* Validation accuracy 0.484; precision 0.413; recall 0.438; train 108.8s; test inference 0.08s; 8 qubits

![confusion 7](plots/confusion/family_07.png)

</details>

<details><summary><b>8. CNN + QNN</b> (hybrid) — acc 0.772, F1 0.772, AUC 0.937</summary>

* Settings: end-to-end
* Validation accuracy 0.789; precision 0.787; recall 0.768; train 881.6s; test inference 6.71s; 8 qubits

![confusion 8](plots/confusion/family_08.png)

</details>

<details><summary><b>9. BiLSTM + QNN</b> (hybrid) — acc 0.570, F1 0.577, AUC 0.848</summary>

* Settings: end-to-end
* Validation accuracy 0.549; precision 0.565; recall 0.605; train 170.5s; test inference 0.36s; 8 qubits

![confusion 9](plots/confusion/family_09.png)

</details>

<details><summary><b>10. QAOA + QNN</b> (quantum) — acc 0.456, F1 0.373, AUC 0.763</summary>

* Settings: QAOA p=2 -> ['TGT', 'AGA', 'GGT', 'CTT', 'CAG', 'TGC'] (approx ratio 1.00, P(opt)=0.001 vs uniform 0.0002)
* Validation accuracy 0.450; precision 0.381; recall 0.380; train 14.4s; test inference 0.02s; 12 qubits
* QAOA selected candidate features: [1, 2, 4, 5, 6, 9]
* Exact QUBO optimum (brute force): [1, 2, 4, 6, 9, 11]
* QAOA approximation ratio: 1.000
* P(optimal bitstring): 0.0009 (uniform = 0.00024)

![confusion 10](plots/confusion/family_10.png)

</details>

<details><summary><b>11. VQE + QNN</b> (quantum) — acc 0.469, F1 0.391, AUC 0.782</summary>

* Settings: VQE E=-6.624 vs exact -7.825
* Validation accuracy 0.486; precision 0.388; recall 0.409; train 101.2s; test inference 0.11s; 8 qubits
* VQE energy: -6.6237
* Exact ground energy: -7.8252

![confusion 11](plots/confusion/family_11.png)

</details>

<details><summary><b>12. QML + CNN</b> (hybrid) — acc 0.831, F1 0.832, AUC 0.972</summary>

* Settings: quanv window=8 stride=4 -> 8x255
* Validation accuracy 0.826; precision 0.845; recall 0.825; train 14.8s; test inference 0.13s; 4 qubits

![confusion 12](plots/confusion/family_12.png)

</details>


---

## Task: `species` — 3-class species identification (human vs chimpanzee vs dog)

**5990** unique sequences, **3** classes → train **4193** / validation **898** / test **899** (stratified 70/15/15, seed 42).

* Best overall: **2. K-mer + SVM**, test accuracy **0.598**, macro F1 **0.531**
* Best quantum / hybrid: **6. PCA + QSVM**, test accuracy **0.594**, macro F1 **0.248**

### Class distribution

| class | train | val | test |
|---|---|---|---|
| human | 2492 | 534 | 534 |
| chimpanzee | 1130 | 242 | 242 |
| dog | 571 | 122 | 123 |


![class distribution](plots/classes_species.png)

### Results (test set)

| id | model | family | val_acc | accuracy | precision | recall | f1 | roc_auc | train_s | infer_s | qubits |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | K-mer + KNN | classical ML | 0.607 | 0.552 | 0.513 | 0.459 | 0.474 | 0.587 | 38.2 | 2.7 | - |
| 2 | K-mer + SVM | classical ML | 0.612 | 0.598 | 0.586 | 0.505 | 0.531 | 0.694 | 25.8 | 0.01 | - |
| 3 | Features + XGBoost | classical ML | 0.569 | 0.586 | 0.608 | 0.427 | 0.446 | 0.729 | 15.1 | 0.00 | - |
| 4 | Encoding + 1D-CNN | deep learning | 0.540 | 0.553 | 0.450 | 0.458 | 0.417 | 0.678 | 14.8 | 0.15 | - |
| 5 | Encoding + CNN-LSTM | deep learning | 0.533 | 0.562 | 0.564 | 0.467 | 0.407 | 0.666 | 11.8 | 0.12 | - |
| 6 | PCA + QSVM | quantum | 0.595 | 0.594 | 0.198 | 0.333 | 0.248 | 0.526 | 2.5 | 0.04 | 8 |
| 7 | PCA + QNN | quantum | 0.463 | 0.445 | 0.397 | 0.398 | 0.380 | 0.615 | 48.4 | 0.08 | 8 |
| 8 | CNN + QNN | hybrid | 0.537 | 0.562 | 0.397 | 0.464 | 0.397 | 0.680 | 311.3 | 6.4 | 8 |
| 9 | BiLSTM + QNN | hybrid | 0.541 | 0.567 | 0.394 | 0.463 | 0.400 | 0.646 | 59.2 | 0.36 | 8 |
| 10 | QAOA + QNN | quantum | 0.454 | 0.476 | 0.419 | 0.422 | 0.405 | 0.618 | 14.8 | 0.02 | 12 |
| 11 | VQE + QNN | quantum | 0.463 | 0.475 | 0.433 | 0.433 | 0.392 | 0.627 | 73.3 | 0.11 | 8 |
| 12 | QML + CNN | hybrid | 0.560 | 0.539 | 0.467 | 0.430 | 0.404 | 0.696 | 10.5 | 0.14 | 4 |


### Model comparison

![accuracy](plots/accuracy_species.png)

![validation vs test](plots/val_vs_test_species.png)  ![training time](plots/time_species.png)

### Confusion matrices (row-normalised)

![confusion matrices](plots/confusion_species.png)

### Per-class F1

![per-class F1](plots/per_class_f1_species.png)

### ROC curves

![ROC](plots/roc_species.png)

### Model details

<details><summary><b>1. K-mer + KNN</b> (classical ML) — acc 0.552, F1 0.474, AUC 0.587</summary>

* Settings: k=1
* Validation accuracy 0.607; precision 0.513; recall 0.459; train 38.2s; test inference 2.68s

![confusion 1](plots/confusion/species_01.png)

</details>

<details><summary><b>2. K-mer + SVM</b> (classical ML) — acc 0.598, F1 0.531, AUC 0.694</summary>

* Settings: C=10.0
* Validation accuracy 0.612; precision 0.586; recall 0.505; train 25.8s; test inference 0.01s

![confusion 2](plots/confusion/species_02.png)

</details>

<details><summary><b>3. Features + XGBoost</b> (classical ML) — acc 0.586, F1 0.446, AUC 0.729</summary>

* Settings: trees=28
* Validation accuracy 0.569; precision 0.608; recall 0.427; train 15.1s; test inference 0.00s

![confusion 3](plots/confusion/species_03.png)

</details>

<details><summary><b>4. Encoding + 1D-CNN</b> (deep learning) — acc 0.553, F1 0.417, AUC 0.678</summary>

* Settings: L=1024
* Validation accuracy 0.540; precision 0.450; recall 0.458; train 14.8s; test inference 0.15s

![confusion 4](plots/confusion/species_04.png)

</details>

<details><summary><b>5. Encoding + CNN-LSTM</b> (deep learning) — acc 0.562, F1 0.407, AUC 0.666</summary>

* Settings: L=1024
* Validation accuracy 0.533; precision 0.564; recall 0.467; train 11.8s; test inference 0.12s

![confusion 5](plots/confusion/species_05.png)

</details>

<details><summary><b>6. PCA + QSVM</b> (quantum) — acc 0.594, F1 0.248, AUC 0.526</summary>

* Settings: ZZ-map bw=0.1 C=1.0 n_train=2000
* Validation accuracy 0.595; precision 0.198; recall 0.333; train 2.5s; test inference 0.04s; 8 qubits

![confusion 6](plots/confusion/species_06.png)

</details>

<details><summary><b>7. PCA + QNN</b> (quantum) — acc 0.445, F1 0.380, AUC 0.615</summary>

* Settings: 3 re-upload blocks
* Validation accuracy 0.463; precision 0.397; recall 0.398; train 48.4s; test inference 0.08s; 8 qubits

![confusion 7](plots/confusion/species_07.png)

</details>

<details><summary><b>8. CNN + QNN</b> (hybrid) — acc 0.562, F1 0.397, AUC 0.680</summary>

* Settings: end-to-end
* Validation accuracy 0.537; precision 0.397; recall 0.464; train 311.3s; test inference 6.35s; 8 qubits

![confusion 8](plots/confusion/species_08.png)

</details>

<details><summary><b>9. BiLSTM + QNN</b> (hybrid) — acc 0.567, F1 0.400, AUC 0.646</summary>

* Settings: end-to-end
* Validation accuracy 0.541; precision 0.394; recall 0.463; train 59.2s; test inference 0.36s; 8 qubits

![confusion 9](plots/confusion/species_09.png)

</details>

<details><summary><b>10. QAOA + QNN</b> (quantum) — acc 0.476, F1 0.405, AUC 0.618</summary>

* Settings: QAOA p=2 -> ['ATG', 'CTC', 'GAC', 'GGT', 'GCA', 'ACT'] (approx ratio 1.00, P(opt)=0.001 vs uniform 0.0002)
* Validation accuracy 0.454; precision 0.419; recall 0.422; train 14.8s; test inference 0.02s; 12 qubits
* QAOA selected candidate features: [0, 3, 4, 6, 8, 9]
* Exact QUBO optimum (brute force): [0, 3, 4, 6, 8, 9]
* QAOA approximation ratio: 1.000
* P(optimal bitstring): 0.0009 (uniform = 0.00024)

![confusion 10](plots/confusion/species_10.png)

</details>

<details><summary><b>11. VQE + QNN</b> (quantum) — acc 0.475, F1 0.392, AUC 0.627</summary>

* Settings: VQE E=-6.118 vs exact -8.233
* Validation accuracy 0.463; precision 0.433; recall 0.433; train 73.3s; test inference 0.11s; 8 qubits
* VQE energy: -6.1179
* Exact ground energy: -8.2326

![confusion 11](plots/confusion/species_11.png)

</details>

<details><summary><b>12. QML + CNN</b> (hybrid) — acc 0.539, F1 0.404, AUC 0.696</summary>

* Settings: quanv window=8 stride=4 -> 8x255
* Validation accuracy 0.560; precision 0.467; recall 0.430; train 10.5s; test inference 0.14s; 4 qubits

![confusion 12](plots/confusion/species_12.png)

</details>

