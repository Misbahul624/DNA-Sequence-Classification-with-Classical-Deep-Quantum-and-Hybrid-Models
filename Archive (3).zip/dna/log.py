"""Tiny timestamped logger. Level 0 = quiet, 1 = normal (default), 2 = debug (per-batch)."""
from __future__ import annotations

import sys
import time

LEVEL = 1
_T0 = time.perf_counter()


def set_level(level: int):
    global LEVEL
    LEVEL = level


def _stamp() -> str:
    s = int(time.perf_counter() - _T0)
    return f"[{s // 3600:02d}:{s % 3600 // 60:02d}:{s % 60:02d}]"


def info(msg: str, indent: int = 1):
    """Progress message (shown unless --quiet)."""
    if LEVEL >= 1:
        print(f"{_stamp()} {'  ' * indent}{msg}", flush=True)


def debug(msg: str, indent: int = 2):
    """Fine-grained message (shown with -v)."""
    if LEVEL >= 2:
        print(f"{_stamp()} {'  ' * indent}{msg}", flush=True)


def always(msg: str = ""):
    print(msg, flush=True)
    sys.stdout.flush()


class Timer:
    """with Timer('building TF-IDF'): ...  -> logs start and duration."""

    def __init__(self, what: str, indent: int = 1):
        self.what, self.indent = what, indent

    def __enter__(self):
        self.t = time.perf_counter()
        info(f"{self.what} ...", self.indent)
        return self

    def __exit__(self, *exc):
        self.elapsed = time.perf_counter() - self.t
        if exc[0] is None:
            info(f"{self.what} done in {self.elapsed:.1f}s", self.indent)
