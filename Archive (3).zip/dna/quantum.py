"""A tiny, exact, differentiable state-vector quantum simulator in PyTorch.

Qubit 0 is the most-significant bit of the basis index. States are (B, 2**n) complex64.
Trainable (data-independent) circuits are compiled into a 2**n x 2**n matrix once per
forward pass, data-dependent RZ / ZZ rotations are diagonal phases, and RY encodings on |0>
are product states - so a whole batch is just a few matmuls.
"""
from __future__ import annotations

import math
from functools import lru_cache

import torch
from torch import nn

CDT = torch.complex64


# ---------------------------------------------------------------- gates
def ry(t: torch.Tensor) -> torch.Tensor:
    c, s = torch.cos(t / 2), torch.sin(t / 2)
    return torch.stack([torch.stack([c, -s], -1), torch.stack([s, c], -1)], -2).to(CDT)


def rz(t: torch.Tensor) -> torch.Tensor:
    t = t.to(CDT)
    e, z = torch.exp(-0.5j * t), torch.zeros_like(t)
    return torch.stack([torch.stack([e, z], -1), torch.stack([z, e.conj()], -1)], -2)


def rx(t: torch.Tensor) -> torch.Tensor:
    c, s = torch.cos(t / 2).to(CDT), torch.sin(t / 2).to(CDT)
    return torch.stack([torch.stack([c, -1j * s], -1), torch.stack([-1j * s, c], -1)], -2)


H_GATE = torch.tensor([[1, 1], [1, -1]], dtype=CDT) / math.sqrt(2)


# ---------------------------------------------------------------- helpers
@lru_cache(maxsize=None)
def zsign(n: int) -> torch.Tensor:
    """(2**n, n) matrix of Z eigenvalues (+1 for |0>, -1 for |1>)."""
    idx = torch.arange(2 ** n)[:, None]
    bits = (idx >> torch.arange(n - 1, -1, -1)) & 1
    return (1 - 2 * bits).float()


def ring_pairs(n: int) -> list[tuple[int, int]]:
    if n < 2:
        return []
    if n == 2:
        return [(0, 1)]
    return [(i, (i + 1) % n) for i in range(n)]


def zero_state(batch: int, n: int) -> torch.Tensor:
    s = torch.zeros(batch, 2 ** n, dtype=CDT)
    s[:, 0] = 1
    return s


def plus_state(batch: int, n: int) -> torch.Tensor:
    return torch.full((batch, 2 ** n), 2 ** (-n / 2), dtype=CDT)


def product_state(theta: torch.Tensor) -> torch.Tensor:
    """RY(theta_q)|0> on every qubit -> (B, 2**n). theta: (B, n)."""
    state = torch.ones(theta.shape[0], 1, dtype=theta.dtype, device=theta.device)
    for q in range(theta.shape[1]):
        v = torch.stack([torch.cos(theta[:, q] / 2), torch.sin(theta[:, q] / 2)], -1)
        state = (state[:, :, None] * v[:, None, :]).reshape(theta.shape[0], -1)
    return state.to(CDT)


def apply_1q(state: torch.Tensor, gate: torch.Tensor, q: int, n: int) -> torch.Tensor:
    """Apply a 2x2 gate (or a batch (B,2,2) of per-sample gates) on qubit q."""
    B = state.shape[0]
    s = state.reshape(B, 2 ** q, 2, 2 ** (n - q - 1))
    if gate.dim() == 2:
        s = torch.einsum("ij,bajc->baic", gate, s)
    else:
        s = torch.einsum("bij,bajc->baic", gate, s)
    return s.reshape(B, -1)


@lru_cache(maxsize=None)
def _cnot_perm(c: int, t: int, n: int) -> torch.Tensor:
    idx = torch.arange(2 ** n)
    cbit = (idx >> (n - 1 - c)) & 1
    return idx ^ (cbit << (n - 1 - t))


def apply_cnot(state: torch.Tensor, c: int, t: int, n: int) -> torch.Tensor:
    return state[:, _cnot_perm(c, t, n)]


def apply_x(state: torch.Tensor, q: int, n: int) -> torch.Tensor:
    return state[:, torch.arange(2 ** n) ^ (1 << (n - 1 - q))]


def phase_rz(state: torch.Tensor, angles: torch.Tensor, n: int) -> torch.Tensor:
    """Per-sample RZ(angles[:, q]) on every qubit (diagonal)."""
    phase = -0.5 * angles @ zsign(n).T.to(angles.device)
    return state * torch.exp(1j * phase.to(torch.float32)).to(CDT)


def phase_zz(state: torch.Tensor, angles: torch.Tensor, pairs, n: int) -> torch.Tensor:
    """Per-sample RZZ(angles[:, p]) on each qubit pair (diagonal)."""
    zs = zsign(n).to(angles.device)
    zz = torch.stack([zs[:, i] * zs[:, j] for i, j in pairs], 1)
    phase = -0.5 * angles @ zz.T
    return state * torch.exp(1j * phase.to(torch.float32)).to(CDT)


def probs(state: torch.Tensor) -> torch.Tensor:
    return state.real ** 2 + state.imag ** 2


def expval_z(state: torch.Tensor, n: int) -> torch.Tensor:
    return probs(state) @ zsign(n).to(state.device)


def expval_zz(state: torch.Tensor, pairs, n: int) -> torch.Tensor:
    zs = zsign(n).to(state.device)
    zz = torch.stack([zs[:, i] * zs[:, j] for i, j in pairs], 1)
    return probs(state) @ zz


def hadamard_all(n: int) -> torch.Tensor:
    """Matrix M with psi_out = psi_in @ M for H on every qubit."""
    m = H_GATE
    for _ in range(n - 1):
        m = torch.kron(m, H_GATE)
    return m.T


# ---------------------------------------------------------------- trainable ansatz
class Ansatz(nn.Module):
    """Hardware-efficient U(theta): per layer RY, RZ on every qubit + ring of CNOTs."""

    def __init__(self, n: int, layers: int = 2, init_scale: float = 0.1):
        super().__init__()
        self.n, self.layers = n, layers
        self.theta = nn.Parameter(init_scale * torch.randn(layers, n, 2))

    def matrix(self) -> torch.Tensor:
        """M such that psi_out = psi_in @ M (rows = U|k>)."""
        n = self.n
        s = torch.eye(2 ** n, dtype=CDT)
        for l in range(self.layers):
            for q in range(n):
                s = apply_1q(s, ry(self.theta[l, q, 0]), q, n)
                s = apply_1q(s, rz(self.theta[l, q, 1]), q, n)
            for c, t in ring_pairs(n):
                s = apply_cnot(s, c, t, n)
        return s

    def forward(self, state: torch.Tensor) -> torch.Tensor:
        return state @ self.matrix()


class QNNLayer(nn.Module):
    """Variational quantum layer with data re-uploading.

    x (B, n) angles -> RY(x)|0>  [or RY(x) applied to `init_state`]
                    -> U_1 -> RZ(x) -> U_2 -> ... -> <Z_i>, <Z_i Z_j>  (B, 2n features)
    """

    def __init__(self, n: int, blocks: int = 2, layers_per_block: int = 1,
                 init_state: torch.Tensor | None = None):
        super().__init__()
        self.n = n
        self.blocks = nn.ModuleList(Ansatz(n, layers_per_block) for _ in range(blocks))
        self.pairs = ring_pairs(n)
        self.register_buffer("init_state", init_state if init_state is not None else torch.empty(0, dtype=CDT))
        self.out_dim = n + len(self.pairs)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.float().cpu()
        if self.init_state.numel():
            psi = self.init_state.expand(x.shape[0], -1)
            for q in range(self.n):
                psi = apply_1q(psi, ry(x[:, q]), q, self.n)
        else:
            psi = product_state(x)
        for i, blk in enumerate(self.blocks):
            psi = blk(psi)
            if i < len(self.blocks) - 1:
                psi = phase_rz(psi, x, self.n)
        return torch.cat([expval_z(psi, self.n), expval_zz(psi, self.pairs, self.n)], 1)


# ---------------------------------------------------------------- quantum kernel
def zz_feature_states(x: torch.Tensor, bandwidth: float = 1.0, reps: int = 2) -> torch.Tensor:
    """ZZ feature map |phi(x)> = [U_phi(x) H^n]^reps |0> for x: (B, n) in [0, pi]."""
    x = x.float() * bandwidth
    n = x.shape[1]
    pairs = ring_pairs(n)
    zz = torch.stack([(math.pi * bandwidth - x[:, i]) * (math.pi * bandwidth - x[:, j]) for i, j in pairs], 1)
    Hn = hadamard_all(n)
    psi = plus_state(x.shape[0], n)
    for r in range(reps):
        psi = phase_rz(psi, 2 * x, n)
        psi = phase_zz(psi, 2 * zz, pairs, n)
        if r < reps - 1:
            psi = psi @ Hn
    return psi


def fidelity_kernel(states_a: torch.Tensor, states_b: torch.Tensor) -> torch.Tensor:
    """K_ij = |<phi(a_i)|phi(b_j)>|^2."""
    return (states_a.conj() @ states_b.T).abs() ** 2
