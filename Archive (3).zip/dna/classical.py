"""Models 1-3: classical machine learning on k-mer features. Hyper-parameters chosen on validation."""
from __future__ import annotations

import time

import numpy as np
from scipy.special import softmax
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import LinearSVC

from . import log
from .evaluate import Result


def _select(make, grid, X, y, Xv, yv, pname):
    """Fit one model per grid value, keep the best validation accuracy."""
    log.info(f"input: {X.shape[0]} train x {X.shape[1]} features; searching {pname} in {grid} on validation")
    best, best_s, best_p = None, -1, None
    for p in grid:
        t0 = time.perf_counter()
        m = make(p).fit(X, y)
        tr = (m.predict(X[:2000]) == y[:2000]).mean()
        s = (m.predict(Xv) == yv).mean()
        mark = ""
        if s > best_s:
            best, best_s, best_p, mark = m, s, p, "  <- best so far"
        log.info(f"{pname}={p:<6} train acc {tr:.3f} | val acc {s:.3f} | {time.perf_counter() - t0:.1f}s{mark}", 2)
    log.info(f"selected {pname}={best_p} (val acc {best_s:.3f})")
    return best, best_p


def kmer_knn(fs, cfg) -> Result:
    (X, Xv, Xt), (y, yv, yt) = fs.tfidf, fs.y
    t0 = time.perf_counter()
    m, k = _select(lambda k: KNeighborsClassifier(k, metric="cosine", weights="distance", n_jobs=-1),
                   [1, 3, 5, 9], X, y, Xv, yv, "k")
    train_t = time.perf_counter() - t0
    return Result.from_models(m.predict_proba, Xv, Xt, train_t, params=f"k={k}")


def kmer_svm(fs, cfg) -> Result:
    (X, Xv, Xt), (y, yv, yt) = fs.tfidf, fs.y
    t0 = time.perf_counter()
    m, C = _select(lambda C: LinearSVC(C=C, max_iter=5000), [0.1, 1.0, 10.0], X, y, Xv, yv, "C")
    train_t = time.perf_counter() - t0
    return Result.from_models(lambda Z: softmax(m.decision_function(Z), 1), Xv, Xt, train_t, params=f"C={C}")


def _xgb_worker(X, y, Xv, yv, Xt, n_est, lr, seed, log_level):
    """Runs in a separate *spawned* process.

    On macOS xgboost and torch each ship their own libomp (OpenMP). Loading both in one process
    makes whichever is used second crash or hang, so xgboost never runs in the torch process.
    """
    from xgboost import XGBClassifier
    from xgboost.callback import TrainingCallback

    log.set_level(log_level)

    class XGBLog(TrainingCallback):
        def __init__(self, every=10):
            self.every, self.t0 = every, time.perf_counter()

        def after_iteration(self, model, epoch, evals_log):
            if (epoch + 1) % self.every == 0:
                hist = evals_log["validation_0"]["mlogloss"]
                log.info(f"round {epoch + 1:4d} | val mlogloss {hist[-1]:.4f} (best {min(hist):.4f}) | "
                         f"{time.perf_counter() - self.t0:.1f}s", 2)
            return False

    t0 = time.perf_counter()
    m = XGBClassifier(
        n_estimators=n_est, max_depth=6, learning_rate=lr, subsample=0.8, colsample_bytree=0.3,
        tree_method="hist", n_jobs=-1, early_stopping_rounds=30, eval_metric="mlogloss",
        random_state=seed, callbacks=[XGBLog(10)],
    ).fit(X, y, eval_set=[(Xv, yv)], verbose=False)
    train_t = time.perf_counter() - t0
    pv = m.predict_proba(Xv)
    t1 = time.perf_counter()
    pt = m.predict_proba(Xt)
    return pv, pt, train_t, time.perf_counter() - t1, m.best_iteration + 1, float(m.best_score)


def feature_xgboost(fs, cfg) -> Result:
    import multiprocessing as mp

    (X, Xv, Xt), (y, yv, yt) = fs.xgb, fs.y
    n_est = 150 if cfg.fast else 600
    log.info(f"input: {X.shape[0]} train x {X.shape[1]} features; up to {n_est} trees, "
             f"early stopping after 30 rounds without val improvement (isolated process)")
    with mp.get_context("spawn").Pool(1) as pool:
        pv, pt, train_t, infer_t, best_it, best_score = pool.apply(
            _xgb_worker, (X, y, Xv, yv, Xt, n_est, 0.15 if cfg.fast else 0.08, cfg.seed, log.LEVEL))
    log.info(f"best iteration {best_it} (val mlogloss {best_score:.4f})")
    return Result(pv, pt, train_t, infer_t, params=f"trees={best_it}")
