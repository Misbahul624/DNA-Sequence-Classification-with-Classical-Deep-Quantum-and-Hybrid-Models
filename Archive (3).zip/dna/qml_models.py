"""Models 6-12: quantum and hybrid quantum-classical models on the torch state-vector simulator."""
from __future__ import annotations

import math
import time

import numpy as np
import torch
from scipy.special import softmax
from sklearn.feature_selection import mutual_info_classif
from sklearn.svm import SVC
from torch import nn
from torch.nn import functional as F

from . import log
from . import quantum as q
from .data import subsample
from .deep import CNNExtractor, fit_torch
from .evaluate import Result
from .features import to_angles


# ---------------------------------------------------------------- shared modules
class QNNClassifier(nn.Module):
    """angles (B, n) -> variational quantum circuit -> <Z>, <ZZ> -> linear read-out."""

    def __init__(self, n: int, n_classes: int, blocks: int = 3, init_state=None):
        super().__init__()
        self.qnn = q.QNNLayer(n, blocks=blocks, init_state=init_state)
        self.head = nn.Linear(self.qnn.out_dim, n_classes)

    def forward(self, x):
        return self.head(self.qnn(x))


class ToAngles(nn.Module):
    """Classical bottleneck: features -> n angles in (0, pi) for the quantum layer."""

    def __init__(self, d_in: int, n: int):
        super().__init__()
        self.lin = nn.Sequential(nn.Linear(d_in, n), nn.LayerNorm(n))

    def forward(self, h):
        return math.pi * torch.sigmoid(self.lin(h))


class CNNQNN(nn.Module):
    def __init__(self, n_classes: int, n_qubits: int = 8):
        super().__init__()
        self.cnn = CNNExtractor()
        self.bridge = ToAngles(self.cnn.out_dim, n_qubits)
        self.qnn = q.QNNLayer(n_qubits, blocks=2)
        self.head = nn.Linear(self.qnn.out_dim, n_classes)

    def forward(self, x):
        return self.head(self.qnn(self.bridge(self.cnn(x))))


class BiLSTMQNN(nn.Module):
    def __init__(self, n_classes: int, n_qubits: int = 8, hidden: int = 64):
        super().__init__()
        # strided conv "tokeniser" (k=8 bases, stride 4) keeps the BiLSTM short and fast
        self.tok = nn.Sequential(nn.Conv1d(4, 32, 8, stride=4), nn.ReLU(), nn.MaxPool1d(2))
        self.lstm = nn.LSTM(32, hidden, batch_first=True, bidirectional=True)
        self.bridge = ToAngles(2 * hidden, n_qubits)
        self.qnn = q.QNNLayer(n_qubits, blocks=2)
        self.head = nn.Linear(self.qnn.out_dim, n_classes)

    def forward(self, x):
        h, _ = self.lstm(self.tok(x).transpose(1, 2))
        h = h.max(1).values                         # max-pool over time of [fwd, bwd] states
        return self.head(self.qnn(self.bridge(h)))


def _train_qnn(model, Xs, fs, cfg, name, **kw) -> Result:
    return fit_torch(model, Xs, fs.y, cfg, quantum=True, epochs=cfg.q_epochs, lr=0.02,
                     batch=64, patience=6, name=name, **kw)


# ---------------------------------------------------------------- 6. PCA + QSVM
def pca_qsvm(fs, cfg) -> Result:
    (X, Xv, Xt), (y, yv, _) = fs.pca, fs.y
    X, y = subsample(X, y, cfg.qsvm_max_train, cfg.seed)
    n = X.shape[1]
    log.info(f"{n}-qubit ZZ feature map (2 reps), {len(y)} train states of dim {2 ** n}; "
             f"grid: bandwidth x C on validation")
    t0 = time.perf_counter()
    best = (-1, None)
    for bw in (0.1, 0.2, 0.4):
        tk = time.perf_counter()
        S, Sv = (q.zz_feature_states(torch.as_tensor(a), bw) for a in (X, Xv))
        K, Kv = q.fidelity_kernel(S, S).numpy(), q.fidelity_kernel(Sv, S).numpy()
        off = K[~np.eye(len(K), dtype=bool)]
        log.info(f"bandwidth {bw}: kernel {K.shape[0]}x{K.shape[1]} in {time.perf_counter() - tk:.1f}s | "
                 f"off-diagonal mean {off.mean():.3f}, std {off.std():.3f}", 2)
        for C in (1.0, 10.0, 100.0):
            m = SVC(C=C, kernel="precomputed").fit(K, y)
            acc = (m.predict(Kv) == yv).mean()
            mark = ""
            if acc > best[0]:
                best, mark = (acc, (bw, C, m, S)), "  <- best so far"
            log.info(f"bw={bw} C={C:<6} train acc {(m.predict(K) == y).mean():.3f} | val acc {acc:.3f} | "
                     f"{len(m.support_)} support vectors{mark}", 3)
    _, (bw, C, m, S) = best
    log.info(f"selected bandwidth={bw}, C={C} (val acc {best[0]:.3f})")
    train_t = time.perf_counter() - t0
    proba = lambda Z: softmax(m.decision_function(
        q.fidelity_kernel(q.zz_feature_states(torch.as_tensor(Z), bw), S).numpy()), 1)
    return Result.from_models(proba, Xv, Xt, train_t, qubits=n,
                              params=f"ZZ-map bw={bw} C={C} n_train={len(y)}")


# ---------------------------------------------------------------- 7. PCA + QNN
def pca_qnn(fs, cfg) -> Result:
    n = fs.pca[0].shape[1]
    return _train_qnn(QNNClassifier(n, fs.n_classes, blocks=3), fs.pca, fs, cfg, "PCA+QNN",
                      qubits=n, params="3 re-upload blocks")


# ---------------------------------------------------------------- 8. CNN + QNN
def cnn_qnn(fs, cfg) -> Result:
    return _train_qnn(CNNQNN(fs.n_classes, cfg.n_qubits), fs.onehot, fs, cfg, "CNN+QNN",
                      qubits=cfg.n_qubits, params="end-to-end")


# ---------------------------------------------------------------- 9. BiLSTM + QNN
def bilstm_qnn(fs, cfg) -> Result:
    return _train_qnn(BiLSTMQNN(fs.n_classes, cfg.n_qubits), fs.onehot, fs, cfg, "BiLSTM+QNN",
                      qubits=cfg.n_qubits, params="end-to-end")


# ---------------------------------------------------------------- 10. QAOA + QNN
def qaoa_feature_selection(F_train: np.ndarray, y: np.ndarray, k: int = 6, p: int = 2,
                           steps: int = 200, alpha: float = 1.0, lam: float = 2.0, seed: int = 0):
    """QUBO feature selection solved with QAOA on an exact simulator.

    minimise  -sum_i r_i x_i + alpha * sum_{i<j} R_ij x_i x_j + lam * (sum_i x_i - k)^2
    r = mutual information with the label (relevance), R = |Pearson corr| (redundancy).
    """
    n = F_train.shape[1]
    r = mutual_info_classif(F_train, y, random_state=seed)
    r = r / (r.max() + 1e-12)
    R = np.abs(np.corrcoef(F_train.T))
    np.fill_diagonal(R, 0)
    bits = ((np.arange(2 ** n)[:, None] >> np.arange(n - 1, -1, -1)) & 1).astype(np.float64)
    cost = -bits @ r + alpha * 0.5 * np.einsum("bi,ij,bj->b", bits, R, bits) + lam * (bits.sum(1) - k) ** 2
    c = torch.as_tensor((cost - cost.mean()) / cost.std(), dtype=torch.float32)

    torch.manual_seed(seed)
    gamma = nn.Parameter(torch.linspace(0.1, 0.5, p))
    beta = nn.Parameter(torch.linspace(0.5, 0.1, p))
    opt = torch.optim.Adam([gamma, beta], lr=0.05)

    def run():
        psi = q.plus_state(1, n)
        for l in range(p):
            psi = psi * torch.exp(-1j * gamma[l] * c).to(q.CDT)
            mix = q.rx(2 * beta[l])
            for j in range(n):
                psi = q.apply_1q(psi, mix, j, n)
        return q.probs(psi)[0]

    log.info(f"QAOA: {n} qubits, p={p}, cost Hamiltonian over {2 ** n} bitstrings, {steps} Adam steps")
    for step in range(steps):
        opt.zero_grad()
        energy = (run() * c).sum()
        energy.backward()
        opt.step()
        if (step + 1) % 25 == 0 or step == 0:
            log.info(f"QAOA step {step + 1:3d}/{steps} | <C> = {energy.item():+.4f} | "
                     f"gamma {[round(v, 3) for v in gamma.tolist()]} beta {[round(v, 3) for v in beta.tolist()]}", 3)
    with torch.no_grad():
        pr = run().numpy()
    feasible = bits.sum(1) == k
    pick = int(np.argmax(np.where(feasible, pr, -1)))      # most probable k-feature bitstring
    opt_idx = int(np.argmin(cost))
    info = {
        "qaoa_selected": np.nonzero(bits[pick])[0].tolist(),
        "exact_optimum": np.nonzero(bits[opt_idx])[0].tolist(),
        "p_optimum": float(pr[opt_idx]),
        "uniform_p": 1 / 2 ** n,
        "approx_ratio": float((cost[pick] - cost.max()) / (cost.min() - cost.max())),
    }
    return info["qaoa_selected"], info


def qaoa_qnn(fs, cfg) -> Result:
    """QAOA chooses 6 of the 12 most informative 3-mer frequencies -> 6-qubit QNN."""
    (K, Kv, Kt), (y, _, _) = fs.kmer3, fs.y
    t0 = time.perf_counter()
    mi = mutual_info_classif(K, y, random_state=cfg.seed)
    cand = np.argsort(mi)[::-1][:cfg.qaoa_candidates]
    log.info(f"candidate 3-mers (top {len(cand)} by mutual information): "
             + ", ".join(f"{fs.kmer3_names[c]}={mi[c]:.3f}" for c in cand))
    sel, info = qaoa_feature_selection(K[:, cand], y, k=cfg.qaoa_k, p=2, seed=cfg.seed)
    cols = cand[sel]
    log.info(f"QAOA picked {[fs.kmer3_names[c] for c in cols]} | exact optimum "
             f"{[fs.kmer3_names[cand[i]] for i in info['exact_optimum']]} | approx ratio {info['approx_ratio']:.3f} | "
             f"P(optimum) {info['p_optimum']:.4f} vs uniform {info['uniform_p']:.5f}")
    Xs = to_angles(K[:, cols], Kv[:, cols], Kt[:, cols])
    qaoa_t = time.perf_counter() - t0
    res = _train_qnn(QNNClassifier(len(cols), fs.n_classes, blocks=3), Xs, fs, cfg, "QAOA+QNN",
                     qubits=cfg.qaoa_candidates,
                     params=f"QAOA p=2 -> {[fs.kmer3_names[c] for c in cols]} (approx ratio "
                            f"{info['approx_ratio']:.2f}, P(opt)={info['p_optimum']:.3f} vs uniform "
                            f"{info['uniform_p']:.4f})")
    res.train_time += qaoa_t
    res.extra = info
    return res


# ---------------------------------------------------------------- 11. VQE + QNN
def feature_hamiltonian(X: np.ndarray, y: np.ndarray, gamma: float = 0.5):
    """Transverse-field Ising H = -sum J_ij Z_i Z_j - sum h_i Z_i - gamma sum X_i.

    J = between-class scatter of standardised features (which feature pairs move together across
    classes), h = per-feature mutual information with the label. Returns (diag, gamma, dense H).
    """
    n = X.shape[1]
    Xs = (X - X.mean(0)) / (X.std(0) + 1e-9)
    classes, counts = np.unique(y, return_counts=True)
    mu = np.stack([Xs[y == c].mean(0) for c in classes])
    J = (mu.T * (counts / counts.sum())) @ mu
    np.fill_diagonal(J, 0)
    J /= np.abs(J).max() + 1e-12
    h = mutual_info_classif(X, y, random_state=0)
    h /= h.max() + 1e-12
    zs = q.zsign(n).double().numpy()
    diag = -np.einsum("bi,ij,bj->b", zs, np.triu(J, 1), zs) - zs @ h
    Hm = np.diag(diag).astype(np.float64)
    for i in range(n):
        flip = np.arange(2 ** n) ^ (1 << (n - 1 - i))
        Hm[np.arange(2 ** n), flip] -= gamma
    return torch.as_tensor(diag, dtype=torch.float32), gamma, Hm


def vqe_ground_state(diag, gamma, n, layers=3, steps=150, seed=0):
    torch.manual_seed(seed)
    ans = q.Ansatz(n, layers, init_scale=0.5)
    opt = torch.optim.Adam(ans.parameters(), lr=0.05)

    def energy():
        psi = q.zero_state(1, n) @ ans.matrix()
        e = (q.probs(psi)[0] * diag).sum()
        for i in range(n):
            e = e - gamma * (psi.conj() * q.apply_x(psi, i, n)).real.sum()
        return e, psi

    log.info(f"VQE: {n} qubits, {layers}-layer hardware-efficient ansatz "
             f"({sum(p.numel() for p in ans.parameters())} angles), {steps} Adam steps")
    for step in range(steps):
        opt.zero_grad()
        e, _ = energy()
        e.backward()
        opt.step()
        if (step + 1) % 25 == 0 or step == 0:
            log.info(f"VQE step {step + 1:3d}/{steps} | <H> = {e.item():+.4f}", 3)
    with torch.no_grad():
        e, psi = energy()
    return psi.detach()[0], float(e)


def vqe_qnn(fs, cfg) -> Result:
    """VQE prepares the ground state of a data-derived Ising Hamiltonian; the QNN starts from it."""
    (X, _, _), (y, _, _) = fs.pca, fs.y
    n = X.shape[1]
    t0 = time.perf_counter()
    diag, gamma, Hm = feature_hamiltonian(X, y)
    psi0, e_vqe = vqe_ground_state(diag, gamma, n, steps=cfg.vqe_steps, seed=cfg.seed)
    e_exact = float(np.linalg.eigvalsh(Hm)[0])
    log.info(f"VQE energy {e_vqe:.4f} vs exact ground energy {e_exact:.4f} "
             f"(gap {e_vqe - e_exact:.4f}); QNN will start from this state")
    vqe_t = time.perf_counter() - t0
    res = _train_qnn(QNNClassifier(n, fs.n_classes, blocks=3, init_state=psi0), fs.pca, fs, cfg,
                     "VQE+QNN", qubits=n,
                     params=f"VQE E={e_vqe:.3f} vs exact {e_exact:.3f}")
    res.train_time += vqe_t
    res.extra = {"vqe_energy": e_vqe, "exact_energy": e_exact}
    return res


# ---------------------------------------------------------------- 12. QML + CNN (quanvolution)
@torch.no_grad()
def quanvolution(onehot: np.ndarray, window: int = 8, stride: int = 4, seed: int = 0,
                 chunk: int = 256) -> np.ndarray:
    """Slide over the sequence; each window's A/C/G/T composition -> 4-qubit fixed random circuit
    Phi(x) -> <Z_i>, <Z_i Z_j> => an 8-channel 'quantum feature map' sequence (B, 8, W)."""
    n = 4
    g = torch.Generator().manual_seed(seed)
    ans = q.Ansatz(n, layers=2)
    ans.theta.copy_(torch.rand(ans.theta.shape, generator=g) * 2 * math.pi)
    M = ans.matrix()
    pairs = q.ring_pairs(n)
    out = []
    n_chunks = int(np.ceil(len(onehot) / chunk))
    for ci, i in enumerate(range(0, len(onehot), chunk)):
        if ci == 0 or (ci + 1) % 5 == 0 or ci + 1 == n_chunks:
            log.debug(f"quanvolution chunk {ci + 1}/{n_chunks}", 3)
        comp = F.avg_pool1d(torch.as_tensor(onehot[i:i + chunk]), window, stride)   # (b, 4, W)
        b, _, W = comp.shape
        psi = q.product_state(math.pi * comp.transpose(1, 2).reshape(-1, n)) @ M
        f = torch.cat([q.expval_z(psi, n), q.expval_zz(psi, pairs, n)], 1)
        out.append(f.reshape(b, W, -1).transpose(1, 2))
    return torch.cat(out).numpy().astype(np.float32)


class QuanvCNN(nn.Module):
    def __init__(self, n_classes: int, c_in: int = 8):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(c_in, 64, 5, padding=2), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 5, padding=2), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 128, 3, padding=1), nn.ReLU(),
            nn.AdaptiveMaxPool1d(1), nn.Flatten(), nn.Dropout(0.2), nn.Linear(128, n_classes),
        )

    def forward(self, x):
        return self.net(x)


def qml_cnn(fs, cfg) -> Result:
    t0 = time.perf_counter()
    Xs = []
    for split, x in zip(("train", "val", "test"), fs.onehot):
        Xs.append(quanvolution(x, seed=cfg.seed))
        log.info(f"quanvolution {split}: {x.shape} -> {Xs[-1].shape} (4 qubits per window)")
    Xs = tuple(Xs)
    qt = time.perf_counter() - t0
    res = fit_torch(QuanvCNN(fs.n_classes), Xs, fs.y, cfg, epochs=cfg.dl_epochs, name="QML+CNN",
                    qubits=4, params=f"quanv window=8 stride=4 -> {Xs[0].shape[1]}x{Xs[0].shape[2]}")
    res.train_time += qt * len(Xs[0]) / sum(len(x) for x in Xs)
    res.infer_time += qt * len(Xs[2]) / sum(len(x) for x in Xs)
    return res
