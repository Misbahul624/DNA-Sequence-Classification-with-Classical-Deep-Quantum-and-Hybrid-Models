"""Feature engineering: k-mers, TF-IDF, composition, one-hot encoding, PCA to qubit angles."""
from __future__ import annotations

from dataclasses import dataclass, field
from itertools import product

import numpy as np
from scipy import sparse
from sklearn.decomposition import PCA
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.preprocessing import MinMaxScaler, StandardScaler

from . import log

BASES = "ACGT"
_LUT = np.full(256, -1, dtype=np.int8)
for _i, _b in enumerate(BASES):
    _LUT[ord(_b)] = _i


def kmers(seq: str, k: int) -> list[str]:
    return [seq[i:i + k] for i in range(len(seq) - k + 1)]


def kmer_vocab(k: int) -> list[str]:
    return ["".join(p) for p in product(BASES, repeat=k)]


def kmer_freq(seqs, k: int) -> np.ndarray:
    """Normalised k-mer frequency matrix over the fixed ACGT vocabulary (k-mers with N ignored)."""
    vec = CountVectorizer(analyzer="char", ngram_range=(k, k), vocabulary=kmer_vocab(k), lowercase=False)
    X = vec.transform(seqs).astype(np.float32).toarray()
    return X / np.maximum(X.sum(1, keepdims=True), 1)


def composition(seqs) -> np.ndarray:
    """A/C/G/T frequency, GC%, GC skew, AT skew, CpG obs/exp, log length, N fraction."""
    out = []
    for s in seqs:
        n = max(len(s), 1)
        a, c, g, t = (s.count(b) / n for b in BASES)
        gc = c + g
        cpg = s.count("CG") / n
        out.append([a, c, g, t, gc,
                    (g - c) / (g + c + 1e-9), (a - t) / (a + t + 1e-9),
                    cpg / (c * g + 1e-9), np.log(n), s.count("N") / n])
    return np.asarray(out, dtype=np.float32)


def one_hot(seqs, length: int) -> np.ndarray:
    """(n, 4, length) one-hot; sequences trimmed / zero-padded, N -> all-zero column."""
    X = np.zeros((len(seqs), 4, length), dtype=np.float32)
    for i, s in enumerate(seqs):
        idx = _LUT[np.frombuffer(s[:length].encode(), dtype=np.uint8)]
        pos = np.nonzero(idx >= 0)[0]
        X[i, idx[pos], pos] = 1.0
    return X


def to_angles(train: np.ndarray, *others: np.ndarray) -> list[np.ndarray]:
    """Standardise -> clip to +-3 sigma -> scale to [0, pi] (fit on train only)."""
    sc = StandardScaler().fit(train)
    mm = MinMaxScaler((0, np.pi)).fit(np.clip(sc.transform(train), -3, 3))
    return [mm.transform(np.clip(sc.transform(x), -3, 3)).astype(np.float32) for x in (train, *others)]


@dataclass
class FeatureSet:
    """All feature views for train / val / test, built once and shared by the 12 models."""
    y: tuple[np.ndarray, np.ndarray, np.ndarray]
    tfidf: tuple                       # sparse k-mer TF-IDF (k=3..6)
    xgb: tuple                         # TF-IDF (k=3..5) + composition
    onehot: tuple                      # (n, 4, L)
    pca: tuple                         # PCA(n_pca) of k-mer freqs, scaled to [0, pi]
    kmer3: tuple                       # 3-mer frequencies (64 interpretable features)
    kmer3_names: list[str] = field(default_factory=list)
    n_classes: int = 0


def build(train, val, test, seq_len: int = 1024, n_pca: int = 8) -> FeatureSet:
    seqs = [list(d["sequence"]) for d in (train, val, test)]
    y = tuple(np.array(d["label"].to_numpy(), copy=True) for d in (train, val, test))
    lens = np.array([len(s) for s in seqs[0]])
    log.info(f"train sequence length: min {lens.min()}, median {int(np.median(lens))}, max {lens.max()} "
             f"({(lens > seq_len).mean():.0%} longer than the {seq_len}-base one-hot window)")

    with log.Timer("[1/5] k-mer TF-IDF (k=3..6) for KNN / SVM"):
        tf = TfidfVectorizer(analyzer="char", ngram_range=(3, 6), lowercase=False,
                             sublinear_tf=True, min_df=2, max_features=20000, dtype=np.float32)
        tfidf = (tf.fit_transform(seqs[0]), tf.transform(seqs[1]), tf.transform(seqs[2]))
    log.info(f"TF-IDF matrix: {tfidf[0].shape[0]} x {tfidf[0].shape[1]}, "
             f"{tfidf[0].nnz / np.prod(tfidf[0].shape):.1%} non-zero", 2)

    with log.Timer("[2/5] TF-IDF (k=3..5) + composition (GC%, skews, CpG) for XGBoost"):
        tf5 = TfidfVectorizer(analyzer="char", ngram_range=(3, 5), lowercase=False,
                              sublinear_tf=True, min_df=2, dtype=np.float32)
        comp = [composition(s) for s in seqs]
        t5 = (tf5.fit_transform(seqs[0]), tf5.transform(seqs[1]), tf5.transform(seqs[2]))
        xgb = tuple(sparse.hstack([a, sparse.csr_matrix(c)]).tocsr() for a, c in zip(t5, comp))
    log.info(f"XGBoost features: {xgb[0].shape[1]} columns; mean GC content {comp[0][:, 4].mean():.1%}", 2)

    with log.Timer(f"[3/5] 3-mer + 4-mer frequencies -> PCA({n_pca}) -> angles in [0, pi]"):
        k34 = [np.hstack([kmer_freq(s, 3), kmer_freq(s, 4)]) for s in seqs]
        sc = StandardScaler().fit(k34[0])
        pca = PCA(n_pca, random_state=0).fit(sc.transform(k34[0]))
        pca_feats = to_angles(*[pca.transform(sc.transform(x)) for x in k34])
    ev = pca.explained_variance_ratio_
    log.info(f"PCA explained variance: {' '.join(f'{v:.3f}' for v in ev)} (total {ev.sum():.1%})", 2)

    with log.Timer(f"[4/5] one-hot encoding (4 x {seq_len})"):
        onehot = tuple(one_hot(s, seq_len) for s in seqs)
    log.info(f"one-hot tensors: {', '.join(str(o.shape) for o in onehot)} "
             f"({sum(o.nbytes for o in onehot) / 1e6:.0f} MB)", 2)

    with log.Timer("[5/5] 3-mer feature pool for QAOA"):
        k3 = tuple(x[:, :64] for x in k34)

    return FeatureSet(
        y=y, tfidf=tfidf, xgb=xgb, onehot=onehot,
        pca=tuple(pca_feats), kmer3=k3, kmer3_names=kmer_vocab(3),
        n_classes=int(max(int(v.max()) for v in y) + 1),
    )
