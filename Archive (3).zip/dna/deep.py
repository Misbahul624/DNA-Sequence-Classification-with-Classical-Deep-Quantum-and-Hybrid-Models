"""Models 4-5 (1D-CNN, CNN-LSTM) and a shared torch training loop with early stopping on validation."""
from __future__ import annotations

import copy
import time

import numpy as np
import torch
from torch import nn

from . import log
from .evaluate import Result


def device_for(cfg, quantum: bool = False) -> torch.device:
    # the quantum simulator uses complex64 -> keep hybrid models on CPU
    if not quantum and cfg.device == "auto":
        if torch.backends.mps.is_available():
            return torch.device("mps")
        if torch.cuda.is_available():
            return torch.device("cuda")
    return torch.device("cpu" if cfg.device == "auto" else cfg.device)


@torch.no_grad()
def predict_proba(model: nn.Module, X: np.ndarray, device, batch: int = 256) -> np.ndarray:
    model.eval()
    out = []
    for i in range(0, len(X), batch):
        xb = torch.as_tensor(X[i:i + batch], device=device)
        out.append(torch.softmax(model(xb).float(), 1).cpu())
    return torch.cat(out).numpy()


def describe(model: nn.Module) -> str:
    n = sum(p.numel() for p in model.parameters())
    nq = sum(p.numel() for name, p in model.named_parameters() if "qnn" in name or "blocks" in name)
    return f"{n:,} trainable parameters" + (f" ({nq} of them quantum circuit angles)" if nq else "")


def train(model: nn.Module, X, y, Xv, yv, cfg, *, device, epochs: int, lr: float = 2e-3,
          batch: int = 64, patience: int = 5, weight_decay: float = 1e-4, log_name: str = "") -> nn.Module:
    """AdamW + class-weighted CE + cosine LR; keeps the weights with the best validation accuracy."""
    torch.manual_seed(cfg.seed)
    model.to(device)
    n_batches = int(np.ceil(len(X) / batch))
    log.info(f"{model.__class__.__name__}: {describe(model)} | device {device} | {len(X)} train / "
             f"{len(Xv)} val | batch {batch} ({n_batches} steps/epoch) | lr {lr} | "
             f"max {epochs} epochs, early-stop patience {patience}")
    counts = np.bincount(y, minlength=int(max(y.max(), yv.max()) + 1)).astype(np.float32)
    w = torch.as_tensor(counts.sum() / np.maximum(counts, 1) / len(counts), device=device)
    lossf = nn.CrossEntropyLoss(weight=w)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    Xt, yt = torch.as_tensor(np.ascontiguousarray(X)), torch.as_tensor(np.array(y, copy=True))
    best_acc, best_ep, best_state, bad = -1.0, 0, None, 0
    rng = np.random.default_rng(cfg.seed)
    report_every = max(1, n_batches // 5)
    for ep in range(epochs):
        model.train()
        t_ep = time.perf_counter()
        perm = rng.permutation(len(X))
        tot_loss, tot_correct, seen = 0.0, 0, 0
        for b, i in enumerate(range(0, len(X), batch)):
            idx = perm[i:i + batch]
            xb, yb = Xt[idx].to(device), yt[idx].to(device)
            opt.zero_grad()
            out = model(xb)
            loss = lossf(out, yb)
            loss.backward()
            opt.step()
            tot_loss += loss.item() * len(idx)
            tot_correct += (out.argmax(1) == yb).sum().item()
            seen += len(idx)
            if (b + 1) % report_every == 0 or b + 1 == n_batches:
                el = time.perf_counter() - t_ep
                log.debug(f"[{log_name}] epoch {ep + 1} batch {b + 1:4d}/{n_batches} | "
                          f"loss {tot_loss / seen:.4f} | acc {tot_correct / seen:.3f} | "
                          f"{seen / el:.0f} seq/s | eta {el / (b + 1) * (n_batches - b - 1):.0f}s", 3)
        sched.step()
        pv = predict_proba(model, Xv, device)
        acc = (pv.argmax(1) == yv).mean()
        vloss = float(-np.log(np.clip(pv[np.arange(len(yv)), yv], 1e-12, None)).mean())
        mark = ""
        if acc > best_acc:
            best_acc, best_ep, best_state, bad = acc, ep + 1, copy.deepcopy(model.state_dict()), 0
            mark = "  * best"
        else:
            bad += 1
        log.info(f"[{log_name}] epoch {ep + 1:2d}/{epochs} | train loss {tot_loss / seen:.4f} "
                 f"acc {tot_correct / seen:.3f} | val loss {vloss:.4f} acc {acc:.3f} | "
                 f"lr {opt.param_groups[0]['lr']:.2e} | {time.perf_counter() - t_ep:.1f}s{mark}", 2)
        if bad >= patience:
            log.info(f"[{log_name}] early stopping: no val improvement for {patience} epochs", 2)
            break
    log.info(f"restoring best weights from epoch {best_ep} (val acc {best_acc:.3f})")
    model.load_state_dict(best_state)
    return model


def fit_torch(model, Xs, ys, cfg, *, quantum=False, epochs=20, lr=2e-3, batch=64, patience=5,
              name="", **kw) -> Result:
    (X, Xv, Xt), (y, yv, _) = Xs, ys
    dev = device_for(cfg, quantum)
    t0 = time.perf_counter()
    model = train(model, X, y, Xv, yv, cfg, device=dev, epochs=epochs, lr=lr, batch=batch,
                  patience=patience, log_name=name)
    train_t = time.perf_counter() - t0
    return Result.from_models(lambda Z: predict_proba(model, Z, dev), Xv, Xt, train_t, **kw)


# ---------------------------------------------------------------- architectures
class CNNExtractor(nn.Module):
    """One-hot DNA (B, 4, L) -> (B, out_dim) motif features."""

    def __init__(self, channels: int = 64, out_dim: int = 128, dropout: float = 0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(4, channels, 9, padding=4), nn.BatchNorm1d(channels), nn.ReLU(), nn.MaxPool1d(4),
            nn.Conv1d(channels, out_dim, 9, padding=4), nn.BatchNorm1d(out_dim), nn.ReLU(), nn.MaxPool1d(4),
            nn.Conv1d(out_dim, out_dim, 5, padding=2), nn.ReLU(),
            nn.AdaptiveMaxPool1d(1), nn.Flatten(), nn.Dropout(dropout),
        )
        self.out_dim = out_dim

    def forward(self, x):
        return self.net(x)


class CNN1D(nn.Module):
    def __init__(self, n_classes: int):
        super().__init__()
        self.features = CNNExtractor()
        self.head = nn.Linear(self.features.out_dim, n_classes)

    def forward(self, x):
        return self.head(self.features(x))


class CNNLSTM(nn.Module):
    def __init__(self, n_classes: int, channels: int = 64, hidden: int = 64):
        super().__init__()
        self.conv = nn.Sequential(
            nn.Conv1d(4, channels, 9, padding=4), nn.BatchNorm1d(channels), nn.ReLU(), nn.MaxPool1d(4),
            nn.Conv1d(channels, channels, 9, padding=4), nn.BatchNorm1d(channels), nn.ReLU(), nn.MaxPool1d(4),
        )
        self.lstm = nn.LSTM(channels, hidden, batch_first=True)
        self.head = nn.Sequential(nn.Dropout(0.2), nn.Linear(hidden, n_classes))

    def forward(self, x):
        h = self.conv(x).transpose(1, 2)          # (B, L/16, C)
        _, (hn, _) = self.lstm(h)
        return self.head(hn[-1])


def onehot_cnn(fs, cfg) -> Result:
    return fit_torch(CNN1D(fs.n_classes), fs.onehot, fs.y, cfg,
                     epochs=cfg.dl_epochs, name="1D-CNN", params=f"L={fs.onehot[0].shape[2]}")


def onehot_cnn_lstm(fs, cfg) -> Result:
    return fit_torch(CNNLSTM(fs.n_classes), fs.onehot, fs.y, cfg,
                     epochs=cfg.dl_epochs, name="CNN-LSTM", params=f"L={fs.onehot[0].shape[2]}")
