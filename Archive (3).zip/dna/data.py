"""Dataset download, parsing, cleaning, de-duplication and train/val/test splitting."""
from __future__ import annotations

import re
import shutil
import subprocess
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split

ROOT = Path(__file__).resolve().parent.parent
RAW_DIR = ROOT / "data" / "raw"
SPLIT_DIR = ROOT / "data" / "splits"

KAGGLE_SLUG = "nageshsingh/dna-sequence-dataset"
SPECIES = ["human", "chimpanzee", "dog"]
FAMILY_NAMES = [
    "GPCR", "Tyr kinase", "Tyr phosphatase", "Synthetase",
    "Synthase", "Ion channel", "Transcr. factor",
]
MIN_LEN = 30
MAX_N_FRAC = 0.05


def download(raw_dir: Path = RAW_DIR) -> Path:
    """Fetch the Kaggle 'DNA Sequence Dataset' (human / chimpanzee / dog) if missing."""
    raw_dir.mkdir(parents=True, exist_ok=True)
    if all((raw_dir / f"{s}.txt").exists() for s in SPECIES):
        return raw_dir
    if shutil.which("kaggle") is None:
        raise RuntimeError(
            "Dataset not found and the `kaggle` CLI is not installed.\n"
            "  pip install kaggle  (and put your token in ~/.kaggle/)\n"
            f"  or download https://www.kaggle.com/datasets/{KAGGLE_SLUG} and unzip into {raw_dir}"
        )
    print(f"Downloading {KAGGLE_SLUG} from Kaggle ...")
    subprocess.run(
        ["kaggle", "datasets", "download", "-d", KAGGLE_SLUG, "-p", str(raw_dir), "--unzip"],
        check=True,
    )
    return raw_dir


def read_fasta(path: Path) -> list[tuple[str, str]]:
    """Minimal FASTA reader -> [(header, sequence)]."""
    records, header, chunks = [], None, []
    for line in Path(path).read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith(">"):
            if header is not None:
                records.append((header, "".join(chunks)))
            header, chunks = line[1:], []
        else:
            chunks.append(line)
    if header is not None:
        records.append((header, "".join(chunks)))
    return records


_NON_ACGT = re.compile(r"[^ACGT]")


def clean(seq: str) -> str:
    """Uppercase, strip whitespace, map any non-ACGT symbol (IUPAC codes etc.) to N."""
    return _NON_ACGT.sub("N", re.sub(r"\s+", "", str(seq).upper()))


def load(task: str = "family", raw_dir: Path = RAW_DIR) -> tuple[pd.DataFrame, list[str]]:
    """Return a clean DataFrame(sequence, label, species) and the class names for `task`."""
    download(raw_dir)
    frames = []
    for s in SPECIES:
        d = pd.read_csv(raw_dir / f"{s}.txt", sep="\t")
        d["species"] = s
        frames.append(d)
    df = pd.concat(frames, ignore_index=True)
    df["sequence"] = df["sequence"].map(clean)
    n_frac = df["sequence"].str.count("N") / df["sequence"].str.len().clip(lower=1)
    df = df[(df["sequence"].str.len() >= MIN_LEN) & (n_frac <= MAX_N_FRAC)]

    if task == "family":
        df["label"] = df["class"].astype(int)
        names = FAMILY_NAMES
    elif task == "species":
        df["label"] = df["species"].map({s: i for i, s in enumerate(SPECIES)})
        names = SPECIES
    else:
        raise ValueError(f"unknown task {task!r}")

    # De-duplicate: identical sequences would leak between splits. Drop sequences whose
    # duplicates carry conflicting labels, keep one copy otherwise.
    n_labels = df.groupby("sequence")["label"].transform("nunique")
    df = df[n_labels == 1].drop_duplicates("sequence")
    return df[["sequence", "label", "species"]].reset_index(drop=True), names


def split(df: pd.DataFrame, task: str, seed: int = 42, val: float = 0.15, test: float = 0.15,
          save: bool = True) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Stratified train / validation / test split (default 70 / 15 / 15)."""
    train, rest = train_test_split(df, test_size=val + test, stratify=df["label"], random_state=seed)
    val_df, test_df = train_test_split(
        rest, test_size=test / (val + test), stratify=rest["label"], random_state=seed
    )
    parts = [p.reset_index(drop=True) for p in (train, val_df, test_df)]
    if save:
        SPLIT_DIR.mkdir(parents=True, exist_ok=True)
        for name, p in zip(("train", "val", "test"), parts):
            p.to_csv(SPLIT_DIR / f"{task}_{name}.csv", index=False)
    return tuple(parts)


def class_counts(*parts: pd.DataFrame) -> pd.DataFrame:
    return pd.DataFrame({n: p["label"].value_counts().sort_index()
                         for n, p in zip(("train", "val", "test"), parts)}).fillna(0).astype(int)


def subsample(X, y, n: int | None, seed: int = 0):
    """Stratified subsample of at most n rows (used to cap quantum-kernel cost)."""
    if n is None or len(y) <= n:
        return X, y
    idx, _ = train_test_split(np.arange(len(y)), train_size=n, stratify=y, random_state=seed)
    return X[idx], y[idx]
