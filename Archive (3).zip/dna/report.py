"""Results table (CSV + Markdown), plots, and a self-contained Markdown report with embedded figures."""
from __future__ import annotations

from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.metrics import auc, f1_score, roc_curve
from sklearn.preprocessing import label_binarize

COLS = ["id", "model", "family", "val_acc", "accuracy", "precision", "recall", "f1", "roc_auc",
        "train_s", "infer_s", "qubits", "params"]
FAMILY_COLORS = {"classical ML": "#4C78A8", "deep learning": "#59A14F", "quantum": "#B279A2",
                 "hybrid": "#F28E2B"}


def table(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows)[COLS]


def to_markdown(df: pd.DataFrame) -> str:
    fmt = df.copy()
    for c in ["val_acc", "accuracy", "precision", "recall", "f1", "roc_auc"]:
        if c in fmt:
            fmt[c] = fmt[c].map(lambda v: f"{v:.3f}")
    for c in ["train_s", "infer_s"]:
        if c in fmt:
            fmt[c] = fmt[c].map(lambda v: f"{v:.1f}" if v >= 1 else f"{v:.2f}")
    if "qubits" in fmt:
        fmt["qubits"] = fmt["qubits"].map(lambda v: str(v) if v else "-")
    head = "| " + " | ".join(fmt.columns) + " |\n|" + "---|" * len(fmt.columns) + "\n"
    return head + "\n".join("| " + " | ".join(map(str, r)) + " |" for r in fmt.values) + "\n"


def _labels(df):
    return [f"{i}. {m}" for i, m in zip(df["id"], df["model"])]


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


# ---------------------------------------------------------------- plots
def plot_class_distribution(counts: pd.DataFrame, task, path):
    fig, ax = plt.subplots(figsize=(9, 3.8))
    counts.plot.bar(ax=ax, color=["#4C78A8", "#F28E2B", "#59A14F"])
    ax.set_title(f"Class distribution per split — {task}")
    ax.set_ylabel("sequences")
    ax.tick_params(axis="x", rotation=30)
    ax.grid(axis="y", alpha=0.3)
    _save(fig, path)


def plot_accuracy(df, task, path):
    fig, ax = plt.subplots(figsize=(12, 5))
    x = np.arange(len(df))
    c = [FAMILY_COLORS[f] for f in df["family"]]
    ax.bar(x - 0.2, df["accuracy"], 0.4, color=c)
    ax.bar(x + 0.2, df["f1"], 0.4, color=c, alpha=0.45)
    for xi, v in zip(x, df["accuracy"]):
        ax.text(xi - 0.2, v + 0.01, f"{v:.2f}", ha="center", fontsize=7)
    ax.set_xticks(x, _labels(df), rotation=35, ha="right")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("test score")
    ax.set_title(f"Test accuracy (solid) and macro F1 (light) — {task}")
    ax.legend([plt.Rectangle((0, 0), 1, 1, color=v) for v in FAMILY_COLORS.values()], FAMILY_COLORS.keys(),
              loc="lower left")
    ax.grid(axis="y", alpha=0.3)
    _save(fig, path)


def plot_val_vs_test(df, task, path):
    fig, ax = plt.subplots(figsize=(6, 5.5))
    for _, r in df.iterrows():
        ax.scatter(r["val_acc"], r["accuracy"], color=FAMILY_COLORS[r["family"]], s=50)
        ax.annotate(str(r["id"]), (r["val_acc"], r["accuracy"]), fontsize=8, xytext=(4, 2),
                    textcoords="offset points")
    lo = min(df["val_acc"].min(), df["accuracy"].min()) - 0.03
    ax.plot([lo, 1], [lo, 1], "k--", lw=0.8)
    ax.set_xlabel("validation accuracy")
    ax.set_ylabel("test accuracy")
    ax.set_title(f"Validation vs test — {task}")
    ax.grid(alpha=0.3)
    _save(fig, path)


def plot_time(df, task, path):
    fig, ax = plt.subplots(figsize=(10, 4.5))
    y = np.arange(len(df))
    ax.barh(y, df["train_s"], color=[FAMILY_COLORS[f] for f in df["family"]])
    ax.set_yticks(y, _labels(df))
    ax.invert_yaxis()
    ax.set_xscale("log")
    ax.set_xlabel("training time, seconds (log scale)")
    ax.set_title(f"Training time — {task}")
    ax.grid(axis="x", alpha=0.3)
    _save(fig, path)


def plot_confusion_grid(rows, class_names, task, path):
    n, cols = len(rows), 4
    nr = int(np.ceil(n / cols))
    fig, axes = plt.subplots(nr, cols, figsize=(4.2 * cols, 3.9 * nr), squeeze=False)
    for ax, r in zip(axes.ravel(), rows):
        _confusion_ax(ax, r["confusion"], class_names, f"{r['id']}. {r['model']}  acc={r['accuracy']:.2f}",
                      annotate=False)
    for ax in axes.ravel()[n:]:
        ax.axis("off")
    _save(fig, path)


def _confusion_ax(ax, cm, class_names, title, annotate=True):
    norm = cm / np.maximum(cm.sum(1, keepdims=True), 1)
    ax.imshow(norm, cmap="Blues", vmin=0, vmax=1)
    ax.set_title(title, fontsize=9)
    ax.set_xticks(range(len(class_names)), class_names, rotation=45, ha="right", fontsize=7)
    ax.set_yticks(range(len(class_names)), class_names, fontsize=7)
    ax.set_xlabel("predicted", fontsize=8)
    ax.set_ylabel("true", fontsize=8)
    if annotate:
        for i in range(cm.shape[0]):
            for j in range(cm.shape[1]):
                ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=7,
                        color="white" if norm[i, j] > 0.5 else "black")


def plot_confusion_single(r, class_names, path):
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    _confusion_ax(ax, r["confusion"], class_names, f"{r['id']}. {r['model']} — test acc {r['accuracy']:.3f}")
    _save(fig, path)


def plot_per_class_f1(rows, y_test, probas, class_names, task, path):
    M = np.array([f1_score(y_test, probas[r["id"]].argmax(1), average=None,
                           labels=list(range(len(class_names))), zero_division=0) for r in rows])
    fig, ax = plt.subplots(figsize=(1.1 * len(class_names) + 4, 0.42 * len(rows) + 1.8))
    ax.imshow(M, cmap="viridis", vmin=0, vmax=1, aspect="auto")
    for i in range(M.shape[0]):
        for j in range(M.shape[1]):
            ax.text(j, i, f"{M[i, j]:.2f}", ha="center", va="center", fontsize=7,
                    color="black" if M[i, j] > 0.6 else "white")
    ax.set_xticks(range(len(class_names)), class_names, rotation=30, ha="right")
    ax.set_yticks(range(len(rows)), [f"{r['id']}. {r['model']}" for r in rows])
    ax.set_title(f"Per-class F1 on test — {task}")
    _save(fig, path)


def plot_roc(rows, y_test, probas, class_names, task, path):
    Y = label_binarize(y_test, classes=list(range(len(class_names))))
    if Y.shape[1] == 1:
        Y = np.hstack([1 - Y, Y])
    fig, ax = plt.subplots(figsize=(7, 6))
    cmap = plt.get_cmap("tab20")
    for i, r in enumerate(rows):
        fpr, tpr, _ = roc_curve(Y.ravel(), probas[r["id"]].ravel())
        ax.plot(fpr, tpr, color=cmap(i), lw=1.4, label=f"{r['id']}. {r['model']} (AUC {auc(fpr, tpr):.3f})")
    ax.plot([0, 1], [0, 1], "k--", lw=0.8)
    ax.set_xlabel("false positive rate")
    ax.set_ylabel("true positive rate")
    ax.set_title(f"Micro-average ROC — {task}")
    ax.legend(fontsize=7, loc="lower right")
    _save(fig, path)


# ---------------------------------------------------------------- per-task output
def save(rows, probas, y_test, class_names, task, out_dir: Path, counts: pd.DataFrame | None = None) -> dict:
    """Write CSV + all plots for one task; returns relative paths of the figures for the report."""
    plots = out_dir / "plots"
    (plots / "confusion").mkdir(parents=True, exist_ok=True)
    df = table(rows)
    df.to_csv(out_dir / f"metrics_{task}.csv", index=False)
    (out_dir / f"summary_{task}.md").write_text(
        f"# Results — task `{task}` (test set, n={len(y_test)})\n\n" + to_markdown(df))

    figs = {}

    def rel(name):
        return f"plots/{name}"

    if counts is not None:
        plot_class_distribution(counts, task, plots / f"classes_{task}.png")
        figs["classes"] = rel(f"classes_{task}.png")
    plot_accuracy(df, task, plots / f"accuracy_{task}.png")
    figs["accuracy"] = rel(f"accuracy_{task}.png")
    plot_val_vs_test(df, task, plots / f"val_vs_test_{task}.png")
    figs["val_vs_test"] = rel(f"val_vs_test_{task}.png")
    plot_time(df, task, plots / f"time_{task}.png")
    figs["time"] = rel(f"time_{task}.png")
    plot_confusion_grid(rows, class_names, task, plots / f"confusion_{task}.png")
    figs["confusion_grid"] = rel(f"confusion_{task}.png")
    plot_per_class_f1(rows, y_test, probas, class_names, task, plots / f"per_class_f1_{task}.png")
    figs["per_class_f1"] = rel(f"per_class_f1_{task}.png")
    plot_roc(rows, y_test, probas, class_names, task, plots / f"roc_{task}.png")
    figs["roc"] = rel(f"roc_{task}.png")
    figs["confusion"] = {}
    for r in rows:
        name = f"confusion/{task}_{r['id']:02d}.png"
        plot_confusion_single(r, class_names, plots / name)
        figs["confusion"][r["id"]] = rel(name)
    return figs


# ---------------------------------------------------------------- markdown report
def task_section(task, info: dict, df: pd.DataFrame, figs: dict, extras: dict, failures: dict) -> str:
    best = df.sort_values(["accuracy", "f1"], ascending=False).iloc[0] if len(df) else None
    best_q = df[df["family"].isin(["quantum", "hybrid"])].sort_values("accuracy", ascending=False)
    s = [f"## Task: `{task}` — {info['description']}\n"]
    s.append(f"**{info['n_total']}** unique sequences, **{info['n_classes']}** classes → "
             f"train **{info['n_train']}** / validation **{info['n_val']}** / test **{info['n_test']}** "
             f"(stratified 70/15/15, seed {info['seed']}).\n")
    if best is not None:
        s.append(f"* Best overall: **{best['id']}. {best['model']}**, test accuracy **{best['accuracy']:.3f}**, "
                 f"macro F1 **{best['f1']:.3f}**")
    if len(best_q):
        b = best_q.iloc[0]
        s.append(f"* Best quantum / hybrid: **{b['id']}. {b['model']}**, test accuracy **{b['accuracy']:.3f}**, "
                 f"macro F1 **{b['f1']:.3f}**")
    for i, err in failures.items():
        s.append(f"* ⚠️ Model {i} failed: `{err}`")
    s.append("")
    s.append("### Class distribution\n")
    s.append(_df_md(info["counts"]))
    if "classes" in figs:
        s.append(f"\n![class distribution]({figs['classes']})\n")
    s.append("### Results (test set)\n")
    s.append(to_markdown(df.drop(columns=["params"])))
    s.append("\n### Model comparison\n")
    s.append(f"![accuracy]({figs['accuracy']})\n")
    s.append(f"![validation vs test]({figs['val_vs_test']})  ![training time]({figs['time']})\n")
    s.append("### Confusion matrices (row-normalised)\n")
    s.append(f"![confusion matrices]({figs['confusion_grid']})\n")
    s.append("### Per-class F1\n")
    s.append(f"![per-class F1]({figs['per_class_f1']})\n")
    s.append("### ROC curves\n")
    s.append(f"![ROC]({figs['roc']})\n")
    s.append("### Model details\n")
    for _, r in df.iterrows():
        s.append(f"<details><summary><b>{r['id']}. {r['model']}</b> ({r['family']}) — acc {r['accuracy']:.3f}, "
                 f"F1 {r['f1']:.3f}, AUC {r['roc_auc']:.3f}</summary>\n")
        s.append(f"* Settings: {r['params']}")
        s.append(f"* Validation accuracy {r['val_acc']:.3f}; precision {r['precision']:.3f}; "
                 f"recall {r['recall']:.3f}; train {r['train_s']:.1f}s; test inference {r['infer_s']:.2f}s"
                 + (f"; {r['qubits']} qubits" if r["qubits"] else ""))
        for k, v in extras.get(r["id"], {}).items():
            s.append(f"* {k}: {v}")
        s.append(f"\n![confusion {r['id']}]({figs['confusion'][r['id']]})\n\n</details>\n")
    return "\n".join(s)


def _df_md(d: pd.DataFrame) -> str:
    cols = [d.index.name or ""] + list(map(str, d.columns))
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    lines += ["| " + " | ".join([str(i)] + [str(v) for v in row]) + " |" for i, row in zip(d.index, d.values)]
    return "\n".join(lines) + "\n"


def write_report(path: Path, sections: list[str], cfg_text: str):
    head = [
        "# DNA Sequence Classification — ML · DL · QML · Hybrid Report",
        f"_Generated {datetime.now():%Y-%m-%d %H:%M}_\n",
        "Pipeline: DNA dataset (Kaggle *DNA Sequence Dataset*: human, chimpanzee, dog) → cleaning & "
        "de-duplication → k-mer / one-hot / composition features → PCA → 12 models → validation-based "
        "model selection → single evaluation on the held-out test set.\n",
        "| # | Model | Family |\n|---|---|---|",
        "| 1 | K-mer + KNN | classical ML |\n| 2 | K-mer + SVM | classical ML |\n"
        "| 3 | Features + XGBoost | classical ML |\n| 4 | Encoding + 1D-CNN | deep learning |\n"
        "| 5 | Encoding + CNN-LSTM | deep learning |\n| 6 | PCA + QSVM | quantum |\n"
        "| 7 | PCA + QNN | quantum |\n| 8 | CNN + QNN | hybrid |\n| 9 | BiLSTM + QNN | hybrid |\n"
        "| 10 | QAOA + QNN | quantum |\n| 11 | VQE + QNN | quantum |\n| 12 | QML + CNN | hybrid |\n",
        "Quantum circuits are run on an exact state-vector simulator (classical simulation, not hardware). "
        "Metrics: accuracy, macro precision / recall / F1, macro one-vs-rest ROC-AUC, training and "
        "inference time.\n",
        f"**Run configuration:** {cfg_text}\n",
    ]
    path.write_text("\n".join(head) + "\n\n" + "\n\n---\n\n".join(sections) + "\n")
