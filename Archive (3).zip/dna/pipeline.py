"""DNA sequence classification — 12 classical / deep / quantum / hybrid models.

    python run.py                          # BOTH tasks, all 12 models -> results/REPORT.md
    python run.py --task family            # gene-family task only
    python run.py --task species           # human vs chimpanzee vs dog only
    python run.py --models 1,2,6,10        # a subset
    python run.py -v                       # also per-batch progress inside each epoch
    python run.py -q                       # quiet: one line per model
    python run.py --full                   # longer training
"""
from __future__ import annotations

import argparse
import hashlib
import json
import pickle
import random
import time
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from . import classical, data, deep, features, log, qml_models, report
from .evaluate import metrics

MODELS = {
    1: ("K-mer + KNN", "classical ML", classical.kmer_knn),
    2: ("K-mer + SVM", "classical ML", classical.kmer_svm),
    3: ("Features + XGBoost", "classical ML", classical.feature_xgboost),
    4: ("Encoding + 1D-CNN", "deep learning", deep.onehot_cnn),
    5: ("Encoding + CNN-LSTM", "deep learning", deep.onehot_cnn_lstm),
    6: ("PCA + QSVM", "quantum", qml_models.pca_qsvm),
    7: ("PCA + QNN", "quantum", qml_models.pca_qnn),
    8: ("CNN + QNN", "hybrid", qml_models.cnn_qnn),
    9: ("BiLSTM + QNN", "hybrid", qml_models.bilstm_qnn),
    10: ("QAOA + QNN", "quantum", qml_models.qaoa_qnn),
    11: ("VQE + QNN", "quantum", qml_models.vqe_qnn),
    12: ("QML + CNN", "hybrid", qml_models.qml_cnn),
}


@dataclass
class Config:
    task: str = "family"
    seed: int = 42
    fast: bool = True
    verbose: bool = False
    device: str = "auto"
    seq_len: int = 1024
    n_pca: int = 8
    n_qubits: int = 8
    dl_epochs: int = 15
    q_epochs: int = 20
    qsvm_max_train: int | None = 2000
    qaoa_candidates: int = 12
    qaoa_k: int = 6
    vqe_steps: int = 150


def seed_all(s: int):
    random.seed(s)
    np.random.seed(s)
    torch.manual_seed(s)


TASK_DESCRIPTION = {
    "family": "7-class gene-family classification (human + chimpanzee + dog pooled)",
    "species": "3-class species identification (human vs chimpanzee vs dog)",
}


def _fmt_extra(model_id: int, extra: dict, fs) -> dict:
    if model_id == 10 and extra:
        return {
            "QAOA selected candidate features": extra["qaoa_selected"],
            "Exact QUBO optimum (brute force)": extra["exact_optimum"],
            "QAOA approximation ratio": f"{extra['approx_ratio']:.3f}",
            "P(optimal bitstring)": f"{extra['p_optimum']:.4f} (uniform = {extra['uniform_p']:.5f})",
        }
    if model_id == 11 and extra:
        return {"VQE energy": f"{extra['vqe_energy']:.4f}",
                "Exact ground energy": f"{extra['exact_energy']:.4f}"}
    return {}


# ---------------------------------------------------------------- resume cache
def fingerprint(cfg: Config, task: str, train, val, test) -> str:
    """Hash of everything that changes a model's result: settings + the exact data splits."""
    settings = {k: v for k, v in asdict(cfg).items() if k not in ("verbose", "device", "task")}
    h = hashlib.sha256(json.dumps({"task": task, **settings}, sort_keys=True).encode())
    for part in (train, val, test):
        h.update(pd.util.hash_pandas_object(part[["sequence", "label"]], index=False).values.tobytes())
    return h.hexdigest()[:16]


def cache_path(out: Path, task: str, model_id: int) -> Path:
    return out / "cache" / f"{task}_{model_id:02d}.pkl"


def load_cached(out, task, model_id, fp):
    p = cache_path(out, task, model_id)
    if not p.exists():
        return None
    try:
        with open(p, "rb") as f:
            entry = pickle.load(f)
    except Exception:
        return None
    return entry if entry.get("fingerprint") == fp else None


def save_cached(out, task, model_id, fp, row, proba, extra):
    p = cache_path(out, task, model_id)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    with open(tmp, "wb") as f:
        pickle.dump({"fingerprint": fp, "row": row, "proba": proba, "extra": extra}, f)
    tmp.replace(p)                                   # atomic: an interrupted save never corrupts it


def run_task(task: str, ids: list[int], cfg: Config, out: Path, resume: bool = False) -> str:
    """Train / validate / test the selected models on one task; returns its report section."""
    cfg.task = task
    seed_all(cfg.seed)

    # ---- data
    df, names = data.load(task)
    train, val, test = data.split(df, task, cfg.seed)
    counts = data.class_counts(train, val, test).rename(index=dict(enumerate(names)))
    counts.index.name = "class"
    log.always(f"\n{'=' * 90}\nTASK '{task}': {TASK_DESCRIPTION[task]}\n{'=' * 90}")
    log.always(f"{len(df)} unique sequences -> train {len(train)} / val {len(val)} / test {len(test)} "
               f"(splits saved to data/splits/{task}_*.csv)")
    log.always(counts.T.to_string() + "\n")

    fp = fingerprint(cfg, task, train, val, test)
    y_test = test["label"].to_numpy()
    n_classes = len(names)
    fs = None

    def get_features():
        nonlocal fs
        if fs is None:
            t0 = time.perf_counter()
            log.info("Building features", 0)
            fs = features.build(train, val, test, seq_len=cfg.seq_len, n_pca=cfg.n_pca)
            log.always(f"Features built in {time.perf_counter() - t0:.1f}s  (TF-IDF k=3..6: "
                       f"{fs.tfidf[0].shape[1]} dims, one-hot: {fs.onehot[0].shape[1:]}, PCA: {fs.pca[0].shape[1]})\n")
        return fs

    # ---- models
    rows, probas, extras, failures = [], {}, {}, {}
    for i in ids:
        name, fam, fn = MODELS[i]
        log.always(f"{'-' * 90}\n[{i:2d}/12] {name}  ({fam})  — model {ids.index(i) + 1} of {len(ids)} in this task")
        cached = load_cached(out, task, i, fp) if resume else None
        if cached is not None:
            rows.append(cached["row"])
            probas[i] = cached["proba"]
            extras[i] = cached["extra"]
            r0 = cached["row"]
            log.always(f"  RESUMED from {cache_path(out, task, i).relative_to(out.parent)} | val acc {r0['val_acc']:.3f} | "
                       f"test acc {r0['accuracy']:.3f}  F1 {r0['f1']:.3f}  AUC {r0['roc_auc']:.3f}")
            continue
        if resume:
            log.info("no matching cached result -> training")
        fs = get_features()
        seed_all(cfg.seed)
        tm = time.perf_counter()
        try:
            r = fn(fs, cfg)
        except Exception as e:  # keep going so one broken model doesn't lose the whole run
            traceback.print_exc()
            failures[i] = f"{type(e).__name__}: {e}"
            continue
        mv = metrics(fs.y[1], r.val_proba, fs.n_classes)
        mt = metrics(fs.y[2], r.test_proba, fs.n_classes)
        rows.append({"id": i, "model": name, "family": fam, "val_acc": mv["accuracy"], **mt,
                     "train_s": r.train_time, "infer_s": r.infer_time, "qubits": r.qubits, "params": r.params})
        probas[i] = r.test_proba
        extras[i] = _fmt_extra(i, r.extra, fs)
        save_cached(out, task, i, fp, rows[-1], probas[i], extras[i])
        log.always(f"  RESULT  val acc {mv['accuracy']:.3f} | test acc {mt['accuracy']:.3f}  "
                   f"P {mt['precision']:.3f}  R {mt['recall']:.3f}  F1 {mt['f1']:.3f}  AUC {mt['roc_auc']:.3f} | "
                   f"train {r.train_time:.1f}s, test inference {r.infer_time:.2f}s, "
                   f"total {time.perf_counter() - tm:.1f}s | {r.params}")
        log.info("confusion matrix (rows = true, cols = predicted):\n" + "\n".join(
            f"      {names[k][:16]:>16} " + " ".join(f"{v:5d}" for v in row) for k, row in enumerate(mt["confusion"])))

    if not rows:
        return f"## Task: `{task}`\n\nAll models failed: {failures}"
    figs = report.save(rows, probas, y_test, names, task, out, counts=counts)
    df_res = report.table(rows)
    log.always("\n" + report.to_markdown(df_res.drop(columns=["params"])))
    info = {"description": TASK_DESCRIPTION[task], "n_total": len(df), "n_classes": n_classes,
            "n_train": len(train), "n_val": len(val), "n_test": len(test), "seed": cfg.seed, "counts": counts}
    return report.task_section(task, info, df_res, figs, extras, failures)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--task", choices=["all", "family", "species"], default="all")
    ap.add_argument("--models", default="all", help="comma-separated ids 1-12 or 'all'")
    ap.add_argument("--full", action="store_true", help="longer training (slower)")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="auto", help="auto | cpu | mps | cuda")
    ap.add_argument("--out", default="results")
    ap.add_argument("-v", "--verbose", action="store_true", help="also log per-batch progress")
    ap.add_argument("-q", "--quiet", action="store_true", help="only one result line per model")
    ap.add_argument("--resume", action="store_true",
                    help="reuse finished models from results/cache/ (same settings + data) and train only the rest")
    a = ap.parse_args()
    log.set_level(0 if a.quiet else 2 if a.verbose else 1)

    cfg = Config(seed=a.seed, fast=not a.full, verbose=a.verbose, device=a.device)
    if a.full:
        cfg.dl_epochs, cfg.q_epochs, cfg.qsvm_max_train, cfg.vqe_steps = 40, 50, None, 300
    ids = list(MODELS) if a.models == "all" else [int(i) for i in a.models.split(",")]
    tasks = ["family", "species"] if a.task == "all" else [a.task]
    out = Path(__file__).resolve().parent.parent / a.out
    out.mkdir(parents=True, exist_ok=True)

    t0 = time.perf_counter()
    report_path = out / "REPORT.md"
    sections = []
    for t in tasks:
        sections.append(run_task(t, ids, cfg, out, resume=a.resume))
        cfg_text = (f"mode={'full' if a.full else 'fast'}, seed={cfg.seed}, sequence length={cfg.seq_len}, "
                    f"PCA={cfg.n_pca}, qubits={cfg.n_qubits}, DL epochs≤{cfg.dl_epochs}, QNN epochs≤{cfg.q_epochs}, "
                    f"QSVM train cap={cfg.qsvm_max_train}, runtime this session "
                    f"{(time.perf_counter() - t0) / 60:.1f} min"
                    + ("" if len(sections) == len(tasks) else f" (in progress: {len(sections)}/{len(tasks)} tasks done)"))
        report.write_report(report_path, sections, cfg_text)       # rewritten after every task
        log.always(f"\nReport updated: {report_path}")
    log.always(f"CSV / plots: {out}/metrics_*.csv, {out}/plots/\n"
               f"Interrupted? Re-run the same command with --resume to continue where it stopped.")

