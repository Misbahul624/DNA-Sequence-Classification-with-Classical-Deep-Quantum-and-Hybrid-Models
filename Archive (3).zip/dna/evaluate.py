"""Metrics and the common Result container."""
from __future__ import annotations

import time
from dataclasses import dataclass, field

import numpy as np
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score, precision_score,
                             recall_score, roc_auc_score)


def timed_predict(fn, X):
    t0 = time.perf_counter()
    p = np.asarray(fn(X), dtype=np.float64)
    return p, time.perf_counter() - t0


@dataclass
class Result:
    val_proba: np.ndarray
    test_proba: np.ndarray
    train_time: float
    infer_time: float              # test-set inference seconds
    params: str = ""
    qubits: int = 0
    extra: dict = field(default_factory=dict)

    @classmethod
    def from_models(cls, predict_proba, Xv, Xt, train_time, **kw) -> "Result":
        pv, _ = timed_predict(predict_proba, Xv)
        pt, it = timed_predict(predict_proba, Xt)
        return cls(pv, pt, train_time, it, **kw)


def metrics(y: np.ndarray, proba: np.ndarray, n_classes: int) -> dict:
    proba = np.clip(proba, 1e-12, None)
    proba = proba / proba.sum(1, keepdims=True)
    pred = proba.argmax(1)
    out = {
        "accuracy": accuracy_score(y, pred),
        "precision": precision_score(y, pred, average="macro", zero_division=0),
        "recall": recall_score(y, pred, average="macro", zero_division=0),
        "f1": f1_score(y, pred, average="macro", zero_division=0),
    }
    try:
        out["roc_auc"] = roc_auc_score(y, proba, multi_class="ovr", average="macro",
                                       labels=list(range(n_classes)))
    except ValueError:
        out["roc_auc"] = float("nan")
    out["confusion"] = confusion_matrix(y, pred, labels=list(range(n_classes)))
    return out
