"""Sanity tests. Run with:  python -m unittest discover tests   (or pytest)."""
import math
import tempfile
import unittest
from pathlib import Path

import numpy as np
import pandas as pd
import torch

from dna import data, features
from dna import quantum as q
from dna.qml_models import feature_hamiltonian, qaoa_feature_selection, vqe_ground_state


class TestData(unittest.TestCase):
    def test_clean(self):
        self.assertEqual(data.clean(" acgtRYn\nAC "), "ACGTNNNAC")

    def test_fasta(self):
        with tempfile.NamedTemporaryFile("w", suffix=".fa", delete=False) as f:
            f.write(">s1 desc\nACGT\nAC\n>s2\nGG\n")
        self.assertEqual(data.read_fasta(Path(f.name)), [("s1 desc", "ACGTAC"), ("s2", "GG")])

    def test_split_disjoint_and_stratified(self):
        rng = np.random.default_rng(0)
        seqs = ["".join(rng.choice(list("ACGT"), 50)) for _ in range(400)]
        df = pd.DataFrame({"sequence": seqs, "label": np.arange(400) % 4})
        tr, va, te = data.split(df, "unit", save=False)
        self.assertEqual(len(tr) + len(va) + len(te), 400)
        self.assertFalse(set(tr.sequence) & set(va.sequence) or set(tr.sequence) & set(te.sequence))
        self.assertEqual(sorted(te.label.unique()), [0, 1, 2, 3])


class TestFeatures(unittest.TestCase):
    def test_kmers(self):
        self.assertEqual(features.kmers("ACGTA", 3), ["ACG", "CGT", "GTA"])
        f = features.kmer_freq(["AAAA"], 2)
        self.assertAlmostEqual(f[0, 0], 1.0)            # 'AA' is first in the vocab

    def test_one_hot(self):
        X = features.one_hot(["ACGN"], 6)
        self.assertEqual(X.shape, (1, 4, 6))
        np.testing.assert_array_equal(X[0].argmax(0)[:3], [0, 1, 2])
        self.assertEqual(X[0, :, 3:].sum(), 0)          # N and padding are zero


class TestSimulator(unittest.TestCase):
    def test_hadamard(self):
        psi = q.zero_state(1, 1) @ q.hadamard_all(1)
        np.testing.assert_allclose(q.probs(psi).numpy(), [[0.5, 0.5]], atol=1e-6)

    def test_bell_state(self):
        psi = q.apply_cnot(q.apply_1q(q.zero_state(1, 2), q.H_GATE, 0, 2), 0, 1, 2)
        np.testing.assert_allclose(q.probs(psi).numpy(), [[0.5, 0, 0, 0.5]], atol=1e-6)
        self.assertAlmostEqual(q.expval_zz(psi, [(0, 1)], 2).item(), 1.0, places=5)

    def test_product_state_matches_gates(self):
        th = torch.tensor([[0.3, 1.1, 2.0]])
        psi = q.zero_state(1, 3)
        for i in range(3):
            psi = q.apply_1q(psi, q.ry(th[0, i]), i, 3)
        np.testing.assert_allclose(q.product_state(th).numpy(), psi.numpy(), atol=1e-6)
        np.testing.assert_allclose(q.expval_z(psi, 3).numpy()[0], np.cos(th[0].numpy()), atol=1e-5)

    def test_rz_phase_matches_gate(self):
        psi = q.plus_state(1, 2)
        a = torch.tensor([[0.4, -1.3]])
        ref = q.apply_1q(q.apply_1q(psi, q.rz(a[0, 0]), 0, 2), q.rz(a[0, 1]), 1, 2)
        np.testing.assert_allclose(q.phase_rz(psi, a, 2).numpy(), ref.numpy(), atol=1e-6)

    def test_ansatz_unitary(self):
        M = q.Ansatz(3, 2).matrix().detach()
        np.testing.assert_allclose((M.conj().T @ M).numpy(), np.eye(8), atol=1e-5)

    def test_kernel(self):
        x = torch.rand(5, 4) * math.pi
        S = q.zz_feature_states(x, 0.5)
        K = q.fidelity_kernel(S, S).numpy()
        np.testing.assert_allclose(np.diag(K), 1, atol=1e-5)
        np.testing.assert_allclose(K, K.T, atol=1e-6)
        self.assertTrue((K >= -1e-6).all() and (K <= 1 + 1e-5).all())

    def test_qnn_gradients(self):
        layer = q.QNNLayer(3, blocks=2)
        out = layer(torch.rand(4, 3))
        self.assertEqual(out.shape, (4, 6))
        out.sum().backward()
        self.assertTrue(all(p.grad is not None for p in layer.parameters()))


class TestQuantumAlgorithms(unittest.TestCase):
    def test_qaoa_selects_k(self):
        rng = np.random.default_rng(0)
        y = rng.integers(0, 3, 300)
        X = rng.normal(size=(300, 6)) + y[:, None] * np.array([1, 1, 0, 0, 0.5, 0])
        sel, info = qaoa_feature_selection(X, y, k=3, steps=60)
        self.assertEqual(len(sel), 3)
        self.assertGreater(info["p_optimum"], info["uniform_p"])

    def test_vqe_close_to_exact(self):
        rng = np.random.default_rng(1)
        y = rng.integers(0, 2, 200)
        X = rng.normal(size=(200, 4)) + y[:, None]
        diag, g, Hm = feature_hamiltonian(X, y)
        _, e = vqe_ground_state(diag, g, 4, steps=200)
        exact = np.linalg.eigvalsh(Hm)[0]
        self.assertLess(e - exact, 0.15 * abs(exact))


if __name__ == "__main__":
    unittest.main()
